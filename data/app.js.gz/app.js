(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))o(a);new MutationObserver(a=>{for(const r of a)if(r.type==="childList")for(const l of r.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&o(l)}).observe(document,{childList:!0,subtree:!0});function n(a){const r={};return a.integrity&&(r.integrity=a.integrity),a.referrerPolicy&&(r.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?r.credentials="include":a.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function o(a){if(a.ep)return;a.ep=!0;const r=n(a);fetch(a.href,r)}})();var te,v,Oe,O,xe,Me,Be,Fe,me,de,ue,Ie,j={},Ne=[],_t=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,ne=Array.isArray;function R(e,t){for(var n in t)e[n]=t[n];return e}function ge(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ht(e,t,n){var o,a,r,l={};for(r in t)r=="key"?o=t[r]:r=="ref"?a=t[r]:l[r]=t[r];if(arguments.length>2&&(l.children=arguments.length>3?te.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)l[r]===void 0&&(l[r]=e.defaultProps[r]);return Q(e,l,o,a,null)}function Q(e,t,n,o,a){var r={type:e,props:t,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:a??++Oe,__i:-1,__u:0};return a==null&&v.vnode!=null&&v.vnode(r),r}function V(e){return e.children}function X(e,t){this.props=e,this.context=t}function F(e,t){if(t==null)return e.__?F(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?F(e):null}function je(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return je(e)}}function _e(e){(!e.__d&&(e.__d=!0)&&O.push(e)&&!ee.__r++||xe!=v.debounceRendering)&&((xe=v.debounceRendering)||Me)(ee)}function ee(){for(var e,t,n,o,a,r,l,d=1;O.length;)O.length>d&&O.sort(Be),e=O.shift(),d=O.length,e.__d&&(n=void 0,o=void 0,a=(o=(t=e).__v).__e,r=[],l=[],t.__P&&((n=R({},o)).__v=o.__v+1,v.vnode&&v.vnode(n),fe(t.__P,n,o,t.__n,t.__P.namespaceURI,32&o.__u?[a]:null,r,a??F(o),!!(32&o.__u),l),n.__v=o.__v,n.__.__k[n.__i]=n,Ge(r,n,l),o.__e=o.__=null,n.__e!=a&&je(n)));ee.__r=0}function qe(e,t,n,o,a,r,l,d,h,c,p){var s,m,_,b,k,w,f,g=o&&o.__k||Ne,P=t.length;for(h=pt(n,t,g,h,P),s=0;s<P;s++)(_=n.__k[s])!=null&&(m=_.__i==-1?j:g[_.__i]||j,_.__i=s,w=fe(e,_,m,a,r,l,d,h,c,p),b=_.__e,_.ref&&m.ref!=_.ref&&(m.ref&&ve(m.ref,null,_),p.push(_.ref,_.__c||b,_)),k==null&&b!=null&&(k=b),(f=!!(4&_.__u))||m.__k===_.__k?h=Ve(_,h,e,f):typeof _.type=="function"&&w!==void 0?h=w:b&&(h=b.nextSibling),_.__u&=-7);return n.__e=k,h}function pt(e,t,n,o,a){var r,l,d,h,c,p=n.length,s=p,m=0;for(e.__k=new Array(a),r=0;r<a;r++)(l=t[r])!=null&&typeof l!="boolean"&&typeof l!="function"?(typeof l=="string"||typeof l=="number"||typeof l=="bigint"||l.constructor==String?l=e.__k[r]=Q(null,l,null,null,null):ne(l)?l=e.__k[r]=Q(V,{children:l},null,null,null):l.constructor==null&&l.__b>0?l=e.__k[r]=Q(l.type,l.props,l.key,l.ref?l.ref:null,l.__v):e.__k[r]=l,h=r+m,l.__=e,l.__b=e.__b+1,d=null,(c=l.__i=mt(l,n,h,s))!=-1&&(s--,(d=n[c])&&(d.__u|=2)),d==null||d.__v==null?(c==-1&&(a>p?m--:a<p&&m++),typeof l.type!="function"&&(l.__u|=4)):c!=h&&(c==h-1?m--:c==h+1?m++:(c>h?m--:m++,l.__u|=4))):e.__k[r]=null;if(s)for(r=0;r<p;r++)(d=n[r])!=null&&(2&d.__u)==0&&(d.__e==o&&(o=F(d)),Je(d,d));return o}function Ve(e,t,n,o){var a,r;if(typeof e.type=="function"){for(a=e.__k,r=0;a&&r<a.length;r++)a[r]&&(a[r].__=e,t=Ve(a[r],t,n,o));return t}e.__e!=t&&(o&&(t&&e.type&&!t.parentNode&&(t=F(e)),n.insertBefore(e.__e,t||null)),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function mt(e,t,n,o){var a,r,l,d=e.key,h=e.type,c=t[n],p=c!=null&&(2&c.__u)==0;if(c===null&&d==null||p&&d==c.key&&h==c.type)return n;if(o>(p?1:0)){for(a=n-1,r=n+1;a>=0||r<t.length;)if((c=t[l=a>=0?a--:r++])!=null&&(2&c.__u)==0&&d==c.key&&h==c.type)return l}return-1}function Te(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||_t.test(t)?n:n+"px"}function K(e,t,n,o,a){var r,l;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof o=="string"&&(e.style.cssText=o=""),o)for(t in o)n&&t in n||Te(e.style,t,"");if(n)for(t in n)o&&n[t]==o[t]||Te(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(Fe,"$1")),l=t.toLowerCase(),t=l in e||t=="onFocusOut"||t=="onFocusIn"?l.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?o?n.u=o.u:(n.u=me,e.addEventListener(t,r?ue:de,r)):e.removeEventListener(t,r?ue:de,r);else{if(a=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function De(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=me++;else if(t.t<n.u)return;return n(v.event?v.event(t):t)}}}function fe(e,t,n,o,a,r,l,d,h,c){var p,s,m,_,b,k,w,f,g,P,x,H,W,M,U,L,A,T=t.type;if(t.constructor!=null)return null;128&n.__u&&(h=!!(32&n.__u),r=[d=t.__e=n.__e]),(p=v.__b)&&p(t);e:if(typeof T=="function")try{if(f=t.props,g="prototype"in T&&T.prototype.render,P=(p=T.contextType)&&o[p.__c],x=p?P?P.props.value:p.__:o,n.__c?w=(s=t.__c=n.__c).__=s.__E:(g?t.__c=s=new T(f,x):(t.__c=s=new X(f,x),s.constructor=T,s.render=ft),P&&P.sub(s),s.state||(s.state={}),s.__n=o,m=s.__d=!0,s.__h=[],s._sb=[]),g&&s.__s==null&&(s.__s=s.state),g&&T.getDerivedStateFromProps!=null&&(s.__s==s.state&&(s.__s=R({},s.__s)),R(s.__s,T.getDerivedStateFromProps(f,s.__s))),_=s.props,b=s.state,s.__v=t,m)g&&T.getDerivedStateFromProps==null&&s.componentWillMount!=null&&s.componentWillMount(),g&&s.componentDidMount!=null&&s.__h.push(s.componentDidMount);else{if(g&&T.getDerivedStateFromProps==null&&f!==_&&s.componentWillReceiveProps!=null&&s.componentWillReceiveProps(f,x),t.__v==n.__v||!s.__e&&s.shouldComponentUpdate!=null&&s.shouldComponentUpdate(f,s.__s,x)===!1){for(t.__v!=n.__v&&(s.props=f,s.state=s.__s,s.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(z){z&&(z.__=t)}),H=0;H<s._sb.length;H++)s.__h.push(s._sb[H]);s._sb=[],s.__h.length&&l.push(s);break e}s.componentWillUpdate!=null&&s.componentWillUpdate(f,s.__s,x),g&&s.componentDidUpdate!=null&&s.__h.push(function(){s.componentDidUpdate(_,b,k)})}if(s.context=x,s.props=f,s.__P=e,s.__e=!1,W=v.__r,M=0,g){for(s.state=s.__s,s.__d=!1,W&&W(t),p=s.render(s.props,s.state,s.context),U=0;U<s._sb.length;U++)s.__h.push(s._sb[U]);s._sb=[]}else do s.__d=!1,W&&W(t),p=s.render(s.props,s.state,s.context),s.state=s.__s;while(s.__d&&++M<25);s.state=s.__s,s.getChildContext!=null&&(o=R(R({},o),s.getChildContext())),g&&!m&&s.getSnapshotBeforeUpdate!=null&&(k=s.getSnapshotBeforeUpdate(_,b)),L=p,p!=null&&p.type===V&&p.key==null&&(L=Ze(p.props.children)),d=qe(e,ne(L)?L:[L],t,n,o,a,r,l,d,h,c),s.base=t.__e,t.__u&=-161,s.__h.length&&l.push(s),w&&(s.__E=s.__=null)}catch(z){if(t.__v=null,h||r!=null)if(z.then){for(t.__u|=h?160:128;d&&d.nodeType==8&&d.nextSibling;)d=d.nextSibling;r[r.indexOf(d)]=null,t.__e=d}else{for(A=r.length;A--;)ge(r[A]);he(t)}else t.__e=n.__e,t.__k=n.__k,z.then||he(t);v.__e(z,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):d=t.__e=gt(n.__e,t,n,o,a,r,l,h,c);return(p=v.diffed)&&p(t),128&t.__u?void 0:d}function he(e){e&&e.__c&&(e.__c.__e=!0),e&&e.__k&&e.__k.forEach(he)}function Ge(e,t,n){for(var o=0;o<n.length;o++)ve(n[o],n[++o],n[++o]);v.__c&&v.__c(t,e),e.some(function(a){try{e=a.__h,a.__h=[],e.some(function(r){r.call(a)})}catch(r){v.__e(r,a.__v)}})}function Ze(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:ne(e)?e.map(Ze):R({},e)}function gt(e,t,n,o,a,r,l,d,h){var c,p,s,m,_,b,k,w=n.props||j,f=t.props,g=t.type;if(g=="svg"?a="http://www.w3.org/2000/svg":g=="math"?a="http://www.w3.org/1998/Math/MathML":a||(a="http://www.w3.org/1999/xhtml"),r!=null){for(c=0;c<r.length;c++)if((_=r[c])&&"setAttribute"in _==!!g&&(g?_.localName==g:_.nodeType==3)){e=_,r[c]=null;break}}if(e==null){if(g==null)return document.createTextNode(f);e=document.createElementNS(a,g,f.is&&f),d&&(v.__m&&v.__m(t,r),d=!1),r=null}if(g==null)w===f||d&&e.data==f||(e.data=f);else{if(r=r&&te.call(e.childNodes),!d&&r!=null)for(w={},c=0;c<e.attributes.length;c++)w[(_=e.attributes[c]).name]=_.value;for(c in w)if(_=w[c],c!="children"){if(c=="dangerouslySetInnerHTML")s=_;else if(!(c in f)){if(c=="value"&&"defaultValue"in f||c=="checked"&&"defaultChecked"in f)continue;K(e,c,null,_,a)}}for(c in f)_=f[c],c=="children"?m=_:c=="dangerouslySetInnerHTML"?p=_:c=="value"?b=_:c=="checked"?k=_:d&&typeof _!="function"||w[c]===_||K(e,c,_,w[c],a);if(p)d||s&&(p.__html==s.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(s&&(e.innerHTML=""),qe(t.type=="template"?e.content:e,ne(m)?m:[m],t,n,o,g=="foreignObject"?"http://www.w3.org/1999/xhtml":a,r,l,r?r[0]:n.__k&&F(n,0),d,h),r!=null)for(c=r.length;c--;)ge(r[c]);d||(c="value",g=="progress"&&b==null?e.removeAttribute("value"):b!=null&&(b!==e[c]||g=="progress"&&!b||g=="option"&&b!=w[c])&&K(e,c,b,w[c],a),c="checked",k!=null&&k!=e[c]&&K(e,c,k,w[c],a))}return e}function ve(e,t,n){try{if(typeof e=="function"){var o=typeof e.__u=="function";o&&e.__u(),o&&t==null||(e.__u=e(t))}else e.current=t}catch(a){v.__e(a,n)}}function Je(e,t,n){var o,a;if(v.unmount&&v.unmount(e),(o=e.ref)&&(o.current&&o.current!=e.__e||ve(o,null,t)),(o=e.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(r){v.__e(r,t)}o.base=o.__P=null}if(o=e.__k)for(a=0;a<o.length;a++)o[a]&&Je(o[a],t,n||typeof e.type!="function");n||ge(e.__e),e.__c=e.__=e.__e=void 0}function ft(e,t,n){return this.constructor(e,n)}function vt(e,t,n){var o,a,r,l;t==document&&(t=document.documentElement),v.__&&v.__(e,t),a=(o=!1)?null:t.__k,r=[],l=[],fe(t,e=t.__k=ht(V,null,[e]),a||j,j,t.namespaceURI,a?null:t.firstChild?te.call(t.childNodes):null,r,a?a.__e:t.firstChild,o,l),Ge(r,e,l)}function bt(e){function t(n){var o,a;return this.getChildContext||(o=new Set,(a={})[t.__c]=this,this.getChildContext=function(){return a},this.componentWillUnmount=function(){o=null},this.shouldComponentUpdate=function(r){this.props.value!=r.value&&o.forEach(function(l){l.__e=!0,_e(l)})},this.sub=function(r){o.add(r);var l=r.componentWillUnmount;r.componentWillUnmount=function(){o&&o.delete(r),l&&l.call(r)}}),n.children}return t.__c="__cC"+Ie++,t.__=e,t.Provider=t.__l=(t.Consumer=function(n,o){return n.children(o)}).contextType=t,t}te=Ne.slice,v={__e:function(e,t,n,o){for(var a,r,l;t=t.__;)if((a=t.__c)&&!a.__)try{if((r=a.constructor)&&r.getDerivedStateFromError!=null&&(a.setState(r.getDerivedStateFromError(e)),l=a.__d),a.componentDidCatch!=null&&(a.componentDidCatch(e,o||{}),l=a.__d),l)return a.__E=a}catch(d){e=d}throw e}},Oe=0,X.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=R({},this.state),typeof e=="function"&&(e=e(R({},n),this.props)),e&&R(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),_e(this))},X.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),_e(this))},X.prototype.render=V,O=[],Me=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Be=function(e,t){return e.__v.__b-t.__v.__b},ee.__r=0,Fe=/(PointerCapture)$|Capture$/i,me=0,de=De(!1),ue=De(!0),Ie=0;var yt=0;function i(e,t,n,o,a,r){t||(t={});var l,d,h=t;if("ref"in h)for(d in h={},t)d=="ref"?l=t[d]:h[d]=t[d];var c={type:e,props:h,key:n,ref:l,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--yt,__i:-1,__u:0,__source:a,__self:r};if(typeof e=="function"&&(l=e.defaultProps))for(d in l)h[d]===void 0&&(h[d]=l[d]);return v.vnode&&v.vnode(c),c}var I,y,ae,Ee,q=0,Ke=[],C=v,We=C.__b,Pe=C.__r,ze=C.diffed,Ue=C.__c,Ae=C.unmount,Re=C.__;function ie(e,t){C.__h&&C.__h(y,e,q||t),q=0;var n=y.__H||(y.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function S(e){return q=1,wt(Ye,e)}function wt(e,t,n){var o=ie(I++,2);if(o.t=e,!o.__c&&(o.__=[Ye(void 0,t),function(d){var h=o.__N?o.__N[0]:o.__[0],c=o.t(h,d);h!==c&&(o.__N=[c,o.__[1]],o.__c.setState({}))}],o.__c=y,!y.__f)){var a=function(d,h,c){if(!o.__c.__H)return!0;var p=o.__c.__H.__.filter(function(m){return!!m.__c});if(p.every(function(m){return!m.__N}))return!r||r.call(this,d,h,c);var s=o.__c.props!==d;return p.forEach(function(m){if(m.__N){var _=m.__[0];m.__=m.__N,m.__N=void 0,_!==m.__[0]&&(s=!0)}}),r&&r.call(this,d,h,c)||s};y.__f=!0;var r=y.shouldComponentUpdate,l=y.componentWillUpdate;y.componentWillUpdate=function(d,h,c){if(this.__e){var p=r;r=void 0,a(d,h,c),r=p}l&&l.call(this,d,h,c)},y.shouldComponentUpdate=a}return o.__N||o.__}function be(e,t){var n=ie(I++,3);!C.__s&&Xe(n.__H,t)&&(n.__=e,n.u=t,y.__H.__h.push(n))}function St(e){return q=5,Qe(function(){return{current:e}},[])}function Qe(e,t){var n=ie(I++,7);return Xe(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function le(e,t){return q=8,Qe(function(){return e},t)}function Ct(e){var t=y.context[e.__c],n=ie(I++,9);return n.c=e,t?(n.__==null&&(n.__=!0,t.sub(y)),t.props.value):e.__}function kt(){for(var e;e=Ke.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(Y),e.__H.__h.forEach(pe),e.__H.__h=[]}catch(t){e.__H.__h=[],C.__e(t,e.__v)}}C.__b=function(e){y=null,We&&We(e)},C.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Re&&Re(e,t)},C.__r=function(e){Pe&&Pe(e),I=0;var t=(y=e.__c).__H;t&&(ae===y?(t.__h=[],y.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(Y),t.__h.forEach(pe),t.__h=[],I=0)),ae=y},C.diffed=function(e){ze&&ze(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(Ke.push(t)!==1&&Ee===C.requestAnimationFrame||((Ee=C.requestAnimationFrame)||xt)(kt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),ae=y=null},C.__c=function(e,t){t.some(function(n){try{n.__h.forEach(Y),n.__h=n.__h.filter(function(o){return!o.__||pe(o)})}catch(o){t.some(function(a){a.__h&&(a.__h=[])}),t=[],C.__e(o,n.__v)}}),Ue&&Ue(e,t)},C.unmount=function(e){Ae&&Ae(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(o){try{Y(o)}catch(a){t=a}}),n.__H=void 0,t&&C.__e(t,n.__v))};var He=typeof requestAnimationFrame=="function";function xt(e){var t,n=function(){clearTimeout(o),He&&cancelAnimationFrame(t),setTimeout(e)},o=setTimeout(n,35);He&&(t=requestAnimationFrame(n))}function Y(e){var t=y,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),y=t}function pe(e){var t=y;e.__c=e.__(),y=t}function Xe(e,t){return!e||e.length!==t.length||t.some(function(n,o){return n!==e[o]})}function Ye(e,t){return typeof t=="function"?t(e):t}function Tt(){const e=window.location.href;return e.includes("127.0.0.1")||e.includes("localhost")?"http://192.168.4.1/api/":(e.endsWith("/")?e.slice(0,-1):e)+"/api/"}const Dt=Tt();async function N(e,t){const n=await fetch(Dt+e,{...t,headers:{"Content-Type":"application/json",...t?.headers}});if(!n.ok)throw new Error(`HTTP ${n.status}`);return n.status===204?{}:n.json()}const B={getStatus:()=>N("status"),updatePower:e=>N("power",{method:"POST",body:JSON.stringify({winderEnabled:e?1:0})}),updateTimer:e=>N(`timer?timerEnabled=${e?1:0}`,{method:"POST"}),updateSettings:e=>N("update",{method:"POST",body:JSON.stringify(e)}),reset:()=>N("reset")},Et={reset:"Reset",on:"on",off:"off",dialog:{title:"Reset takes 20 seconds",subtitle:"This screen will not close during the reset process",cancel:"Cancel",point1:"Reset is complete when the second LED stops fast blinking, then turns solid.",point2:"Connect your mobile device to the new WiFi network called",point3:"Add Winderoo to an existing WiFi network. If the LED starts to slow blink, Winderoo has successfully joined that network.",point4:"Wait for your device to reconnect to your existing WiFi network.",nowAvailable:"Winderoo is now available at:",confirmReset:"Confirm Reset"}},Wt={status:"Status",stopped:"Stopped",winding:"Winding",estimatedDuration:"Estimated Cycle Duration",direction:"Direction",rotationsPerDay:"Rotations Per Day",findWindingParameters:"Find your watch's winding parameters",cycleStart:"Cycle Start Time",enabled:"Enabled",disabled:"Disabled",hours:"Hour",minutes:"Minutes",save:"Save",saveInProgress:"Saving...",clockwise:"Clockwise",counterClockwise:"Counter Clockwise",both:"Both",pleaseWait:"Getting cycle progress...",progress:"Cycle Progress",screen:"OLED Screen",screenSchedule:"Screen Schedule",enableSchedule:"Enable Schedule",turnOnScreenAt:"Turn On At",turnOffScreenAt:"Turn Off At",customize:"Settings & Customization",rotationDurationTime:"Time to rotate",rotationPauseTime:"Time to pause",seconds:"seconds",internalClock:"Internal Clock",internalClockBlurb:"Winderoo has an internal clock (RTC), which is automatically set during boot.",internalClockBlurb2:"If this is incorrect, please update the clock beneath.",utcOffset:"UTC Offset",dst:"Daylight Savings Time",loading:"Loading...",singleRotationTiming:"Time for one rotation"},Pt={header:Et,settings:Wt},zt={reset:"Zurücksetzen",on:"an",off:"aus",dialog:{title:"Das Zurücksetzen dauert 20 Sekunden",subtitle:"Dieser Bildschirm wird während des Zurücksetzens nicht geschlossen",cancel:"Abbrechen",point1:"Das Zurücksetzen ist abgeschlossen, wenn die zweite LED aufhört schnell zu blinken und dann durchgehend leuchtet.",point2:"Verbinden Sie Ihr Mobilgerät mit dem neuen WiFi-Netzwerk namens",point3:"Fügen Sie Winderoo einem bestehenden WiFi-Netzwerk hinzu. Wenn die LED langsam zu blinken beginnt, hat Winderoo erfolgreich das Netzwerk beigetreten.",point4:"Warten Sie, bis Ihr Gerät sich wieder mit Ihrem bestehenden WiFi-Netzwerk verbindet.",nowAvailable:"Winderoo ist jetzt verfügbar unter:",confirmReset:"Zurücksetzen bestätigen"}},Ut={status:"Status",stopped:"Gestoppt",winding:"Aufziehend",estimatedDuration:"Geschätzte Zyklusdauer",direction:"Richtung",rotationsPerDay:"Umdrehungen pro Tag",findWindingParameters:"Finden Sie die Aufziehparameter Ihrer Uhr",cycleStart:"Zyklus-Startzeit",enabled:"Aktiviert",disabled:"Deaktiviert",hours:"Stunde",minutes:"Minuten",save:"Speichern",saveInProgress:"Speichern...",clockwise:"Im Uhrzeigersinn",counterClockwise:"Gegen den Uhrzeigersinn",both:"Beide",pleaseWait:"Zyklusfortschritt wird geladen...",progress:"Zyklusfortschritt",screen:"OLED-Bildschirm",screenSchedule:"Bildschirmzeitplan",enableSchedule:"Zeitplan aktivieren",turnOnScreenAt:"Einschalten um",turnOffScreenAt:"Ausschalten um",customize:"Einstellungen & Anpassung",rotationDurationTime:"Rotationsdauer",rotationPauseTime:"Pausenzeit",seconds:"Sekunden",internalClock:"Interne Uhr",internalClockBlurb:"Winderoo hat eine interne Uhr (RTC), die beim Start automatisch eingestellt wird.",internalClockBlurb2:"Wenn dies nicht korrekt ist, aktualisieren Sie bitte die Uhr unten.",utcOffset:"UTC-Versatz",dst:"Sommerzeit",loading:"Laden...",singleRotationTiming:"Zeit für eine Umdrehung"},At={header:zt,settings:Ut},Rt={reset:"Reiniciar",on:"encendido",off:"apagado",dialog:{title:"El reinicio tarda 20 segundos",subtitle:"Esta pantalla no se cerrará durante el proceso de reinicio",cancel:"Cancelar",point1:"El reinicio está completo cuando el segundo LED deja de parpadear rápido y luego se queda fijo.",point2:"Conecte su dispositivo móvil a la nueva red WiFi llamada",point3:"Agregue Winderoo a una red WiFi existente. Si el LED comienza a parpadear lentamente, Winderoo se ha unido exitosamente a esa red.",point4:"Espere a que su dispositivo se reconecte a su red WiFi existente.",nowAvailable:"Winderoo está ahora disponible en:",confirmReset:"Confirmar Reinicio"}},Ht={status:"Estado",stopped:"Detenido",winding:"En marcha",estimatedDuration:"Duración estimada del ciclo",direction:"Dirección",rotationsPerDay:"Rotaciones por día",findWindingParameters:"Encuentra los parámetros de cuerda de tu reloj",cycleStart:"Hora de inicio del ciclo",enabled:"Habilitado",disabled:"Deshabilitado",hours:"Hora",minutes:"Minutos",save:"Guardar",saveInProgress:"Guardando...",clockwise:"Sentido horario",counterClockwise:"Sentido antihorario",both:"Ambos",pleaseWait:"Obteniendo progreso del ciclo...",progress:"Progreso del ciclo",screen:"Pantalla OLED",screenSchedule:"Programación de pantalla",enableSchedule:"Habilitar programación",turnOnScreenAt:"Encender a las",turnOffScreenAt:"Apagar a las",customize:"Configuración y personalización",rotationDurationTime:"Tiempo de rotación",rotationPauseTime:"Tiempo de pausa",seconds:"segundos",internalClock:"Reloj interno",internalClockBlurb:"Winderoo tiene un reloj interno (RTC), que se configura automáticamente durante el arranque.",internalClockBlurb2:"Si esto es incorrecto, actualice el reloj a continuación.",utcOffset:"Desplazamiento UTC",dst:"Horario de verano",loading:"Cargando...",singleRotationTiming:"Tiempo para una rotación"},Lt={header:Rt,settings:Ht},$t={reset:"Réinitialiser",on:"activé",off:"désactivé",dialog:{title:"La réinitialisation prend 20 secondes",subtitle:"Cet écran ne se fermera pas pendant le processus de réinitialisation",cancel:"Annuler",point1:"La réinitialisation est terminée lorsque la deuxième LED arrête de clignoter rapidement, puis reste allumée.",point2:"Connectez votre appareil mobile au nouveau réseau WiFi appelé",point3:"Ajoutez Winderoo à un réseau WiFi existant. Si la LED commence à clignoter lentement, Winderoo a rejoint ce réseau avec succès.",point4:"Attendez que votre appareil se reconnecte à votre réseau WiFi existant.",nowAvailable:"Winderoo est maintenant disponible à:",confirmReset:"Confirmer la réinitialisation"}},Ot={status:"Statut",stopped:"Arrêté",winding:"En marche",estimatedDuration:"Durée estimée du cycle",direction:"Direction",rotationsPerDay:"Rotations par jour",findWindingParameters:"Trouvez les paramètres de remontage de votre montre",cycleStart:"Heure de début du cycle",enabled:"Activé",disabled:"Désactivé",hours:"Heure",minutes:"Minutes",save:"Enregistrer",saveInProgress:"Enregistrement...",clockwise:"Sens horaire",counterClockwise:"Sens antihoraire",both:"Les deux",pleaseWait:"Obtention de la progression du cycle...",progress:"Progression du cycle",screen:"Écran OLED",screenSchedule:"Programmation de l'écran",enableSchedule:"Activer la programmation",turnOnScreenAt:"Allumer à",turnOffScreenAt:"Éteindre à",customize:"Paramètres et personnalisation",rotationDurationTime:"Durée de rotation",rotationPauseTime:"Durée de pause",seconds:"secondes",internalClock:"Horloge interne",internalClockBlurb:"Winderoo possède une horloge interne (RTC), qui est automatiquement réglée au démarrage.",internalClockBlurb2:"Si c'est incorrect, veuillez mettre à jour l'horloge ci-dessous.",utcOffset:"Décalage UTC",dst:"Heure d'été",loading:"Chargement...",singleRotationTiming:"Temps pour une rotation"},Mt={header:$t,settings:Ot},Bt={reset:"Reiniciar",on:"ligado",off:"desligado",dialog:{title:"A reinicialização leva 20 segundos",subtitle:"Esta tela não fechará durante o processo de reinicialização",cancel:"Cancelar",point1:"A reinicialização está completa quando o segundo LED para de piscar rapidamente e fica fixo.",point2:"Conecte seu dispositivo móvel à nova rede WiFi chamada",point3:"Adicione Winderoo a uma rede WiFi existente. Se o LED começar a piscar lentamente, Winderoo entrou com sucesso nessa rede.",point4:"Aguarde seu dispositivo se reconectar à sua rede WiFi existente.",nowAvailable:"Winderoo está agora disponível em:",confirmReset:"Confirmar Reinicialização"}},Ft={status:"Status",stopped:"Parado",winding:"Girando",estimatedDuration:"Duração estimada do ciclo",direction:"Direção",rotationsPerDay:"Rotações por dia",findWindingParameters:"Encontre os parâmetros de corda do seu relógio",cycleStart:"Hora de início do ciclo",enabled:"Habilitado",disabled:"Desabilitado",hours:"Hora",minutes:"Minutos",save:"Salvar",saveInProgress:"Salvando...",clockwise:"Sentido horário",counterClockwise:"Sentido anti-horário",both:"Ambos",pleaseWait:"Obtendo progresso do ciclo...",progress:"Progresso do ciclo",screen:"Tela OLED",screenSchedule:"Agendamento de tela",enableSchedule:"Habilitar agendamento",turnOnScreenAt:"Ligar às",turnOffScreenAt:"Desligar às",customize:"Configurações e personalização",rotationDurationTime:"Tempo de rotação",rotationPauseTime:"Tempo de pausa",seconds:"segundos",internalClock:"Relógio interno",internalClockBlurb:"Winderoo possui um relógio interno (RTC), que é configurado automaticamente durante a inicialização.",internalClockBlurb2:"Se estiver incorreto, atualize o relógio abaixo.",utcOffset:"Deslocamento UTC",dst:"Horário de verão",loading:"Carregando...",singleRotationTiming:"Tempo para uma rotação"},It={header:Bt,settings:Ft},Le={"en-US":Pt,"de-DE":At,"es-ES":Lt,"fr-FR":Mt,"pt-BR":It},Nt=[{code:"en-US",name:"English"},{code:"de-DE",name:"Deutsch"},{code:"es-ES",name:"Español"},{code:"fr-FR",name:"Français"},{code:"pt-BR",name:"Português"}];function jt(e){return Le[e]||Le["en-US"]}const et=bt(null);function qt({children:e}){const[t,n]=S(null),[o,a]=S(!0),[r,l]=S(null),[d,h]=S(()=>localStorage.getItem("selectedLanguage")||"en-US"),c=jt(d),p=le(_=>{h(_),localStorage.setItem("selectedLanguage",_)},[]),s=le(async()=>{try{a(!0),l(null);const _=await B.getStatus();_.db=Math.abs(_.db),n(_)}catch(_){l(_ instanceof Error?_.message:"Failed to fetch status")}finally{a(!1)}},[]),m=le(async _=>{try{await B.updatePower(_),await s()}catch(b){l(b instanceof Error?b.message:"Failed to update power")}},[s]);return be(()=>{s()},[s]),i(et.Provider,{value:{status:t,loading:o,error:r,language:d,translations:c,setLanguage:p,refresh:s,setPower:m},children:e})}function tt(){const e=Ct(et);if(!e)throw new Error("useStore must be used within StoreProvider");return e}const D={width:"20px",height:"20px",fill:"currentColor"},E={Watch:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"})}),Bolt:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66.19-.34.05-.08.07-.12C8.48 10.94 10.42 7.54 13 3h1l-1 7h3.5c.49 0 .56.33.47.51l-.07.15C12.96 17.55 11 21 11 21z"})}),Globe:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"})}),Play:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M8 5v14l11-7z"})}),Stop:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M6 6h12v12H6z"})}),RotateCW:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"})}),RotateCCW:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M12 4V1l4 4-4 4V6c-3.31 0-6 2.69-6 6 0 1.01.25 1.97.7 2.8l-1.46 1.46C4.46 15.03 4 13.57 4 12c0-4.42 3.58-8 8-8zm0 14c3.31 0 6-2.69 6-6 0-1.01-.25-1.97-.7-2.8l1.46-1.46c.78 1.23 1.24 2.69 1.24 4.26 0 4.42-3.58 8-8 8v3l-4-4 4-4v3z"})}),Sync:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"})}),Wifi:e=>{const t=e.bars??3;return i("svg",{style:D,viewBox:"0 0 24 24",children:[t>=1&&i("path",{d:"M12 18c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"}),t>=2&&i("path",{d:"M12 14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2h2c0-2.21-1.79-4-4-4z",opacity:t>=2?1:.3}),t>=3&&i("path",{d:"M12 10c-4.42 0-8 3.58-8 8h2c0-3.31 2.69-6 6-6s6 2.69 6 6h2c0-4.42-3.58-8-8-8z",opacity:t>=3?1:.3})]})},Clock:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"})}),ExternalLink:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"})}),Display:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M21 3H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h5v2h8v-2h5c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 14H3V5h18v12z"})}),Settings:()=>i("svg",{style:D,viewBox:"0 0 24 24",children:i("path",{d:"M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"})})};function Vt(){const{status:e,translations:t,language:n,setLanguage:o,setPower:a,refresh:r}=tt(),[l,d]=S(!1),[h,c]=S(!1),p=e?.winderEnabled===1;return i(V,{children:[i("header",{class:"header",children:i("div",{class:"header-content",children:[i("h1",{class:"logo",children:[i(E.Watch,{}),"Winderoo"]}),i("div",{class:"header-actions",children:[i("div",{class:"power-toggle",children:[i("span",{class:"toggle-label",children:p?t.header.on:t.header.off}),i("button",{class:`toggle ${p?"active":""}`,onClick:()=>a(!p),"aria-label":"Toggle power"})]}),i("button",{class:"btn btn-outline btn-icon",onClick:()=>c(!0),title:t.header.reset,children:i(E.Bolt,{})}),i("div",{class:"lang-menu-wrapper",children:[i("button",{class:"btn btn-outline btn-icon",onClick:()=>d(!l),children:i(E.Globe,{})}),l&&i("div",{class:"lang-menu",children:Nt.map(s=>i("button",{class:`lang-option ${n===s.code?"active":""}`,onClick:()=>{o(s.code),d(!1)},children:s.name},s.code))})]})]})]})}),h&&i("div",{class:"dialog-overlay",onClick:()=>c(!1),children:i("div",{class:"dialog",onClick:s=>s.stopPropagation(),children:[i("h2",{children:t.header.dialog.title}),i("p",{class:"text-secondary mt-2",children:t.header.dialog.subtitle}),i("ul",{class:"reset-steps",children:[i("li",{children:t.header.dialog.point1}),i("li",{children:[t.header.dialog.point2," ",i("strong",{children:"Winderoo"})]}),i("li",{children:t.header.dialog.point3}),i("li",{children:t.header.dialog.point4})]}),i("p",{class:"text-sm text-muted mt-3",children:t.header.dialog.nowAvailable}),i("code",{class:"hostname",children:"http://winderoo.local"}),i("div",{class:"dialog-actions",children:[i("button",{class:"btn btn-outline",onClick:()=>c(!1),children:t.header.dialog.cancel}),i("button",{class:"btn btn-danger",onClick:async()=>{await B.reset(),c(!1),setTimeout(r,2e4)},children:t.header.dialog.confirmReset})]})]})}),i("style",{children:`
        .header {
          background: var(--bg-secondary);
          border-bottom: 1px solid var(--border);
          padding: 1rem;
          position: sticky;
          top: 0;
          z-index: 100;
          backdrop-filter: blur(10px);
        }

        .header-content {
          max-width: 600px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .logo {
          font-size: 1.25rem;
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: linear-gradient(135deg, var(--accent), var(--accent-hover));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .power-toggle {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .toggle-label {
          font-size: 0.75rem;
          text-transform: uppercase;
          font-weight: 600;
          color: var(--text-secondary);
        }

        .lang-menu-wrapper {
          position: relative;
        }

        .lang-menu {
          position: absolute;
          top: 100%;
          right: 0;
          margin-top: 0.5rem;
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          overflow: hidden;
          min-width: 140px;
          box-shadow: var(--shadow);
        }

        .lang-option {
          width: 100%;
          padding: 0.75rem 1rem;
          text-align: left;
          transition: var(--transition);
        }

        .lang-option:hover {
          background: var(--bg-card-hover);
        }

        .lang-option.active {
          color: var(--accent);
          background: var(--accent-glow);
        }

        .dialog-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 1rem;
          z-index: 200;
          backdrop-filter: blur(4px);
        }

        .dialog {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 1.5rem;
          max-width: 400px;
          width: 100%;
        }

        .reset-steps {
          margin: 1rem 0;
          padding-left: 1.25rem;
          color: var(--text-secondary);
          font-size: 0.875rem;
        }

        .reset-steps li {
          margin-bottom: 0.5rem;
        }

        .hostname {
          display: block;
          background: var(--bg-secondary);
          padding: 0.5rem 1rem;
          border-radius: var(--radius-sm);
          font-size: 0.875rem;
          margin-top: 0.5rem;
        }

        .dialog-actions {
          display: flex;
          gap: 0.75rem;
          margin-top: 1.5rem;
          justify-content: flex-end;
        }
      `})]})}function Gt(e){const[t,n]=S(e),o=St(null);return be(()=>(n(e),o.current&&clearInterval(o.current),o.current=window.setInterval(()=>{n(a=>a+1)},1e3),()=>{o.current&&clearInterval(o.current)}),[e]),t}function Zt(e){return new Date(e*1e3).toLocaleTimeString("en-US",{timeZone:"UTC",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:!1})}const ce=Array.from({length:24},(e,t)=>t.toString().padStart(2,"0")),Jt=["00","10","20","30","40","50"],$e=Array.from({length:60},(e,t)=>t.toString().padStart(2,"0")),Kt=[{value:-12,label:"UTC-12:00"},{value:-11,label:"UTC-11:00"},{value:-10,label:"UTC-10:00"},{value:-9,label:"UTC-09:00"},{value:-8,label:"UTC-08:00"},{value:-7,label:"UTC-07:00"},{value:-6,label:"UTC-06:00"},{value:-5,label:"UTC-05:00"},{value:-4,label:"UTC-04:00"},{value:-3,label:"UTC-03:00"},{value:-2,label:"UTC-02:00"},{value:-1,label:"UTC-01:00"},{value:0,label:"UTC±00:00"},{value:1,label:"UTC+01:00"},{value:2,label:"UTC+02:00"},{value:3,label:"UTC+03:00"},{value:4,label:"UTC+04:00"},{value:5,label:"UTC+05:00"},{value:5.5,label:"UTC+05:30"},{value:6,label:"UTC+06:00"},{value:7,label:"UTC+07:00"},{value:8,label:"UTC+08:00"},{value:9,label:"UTC+09:00"},{value:10,label:"UTC+10:00"},{value:11,label:"UTC+11:00"},{value:12,label:"UTC+12:00"}];function Qt(){const{status:e,loading:t,translations:n,refresh:o}=tt(),[a,r]=S(!1),[l,d]=S("CW"),[h,c]=S(650),[p,s]=S(!1),[m,_]=S("08"),[b,k]=S("00"),[w,f]=S(!1),[g,P]=S(!1),[x,H]=S({hour:"08",minute:"00"}),[W,M]=S({hour:"22",minute:"00"}),[U,L]=S(180),[A,T]=S(15),[z,ye]=S(8),[we,Se]=S(0),[re,Ce]=S(!1);be(()=>{if(e){if(d(e.direction),c(e.rotationsPerDay),s(e.timerEnabled===1),_(e.hour),k(e.minutes),f(e.screenSleep),P(e.screenScheduleEnabled),e.screenScheduleStartTime){const[u,$]=e.screenScheduleStartTime.split(":");H({hour:u,minute:$})}if(e.screenScheduleEndTime){const[u,$]=e.screenScheduleEndTime.split(":");M({hour:u,minute:$})}L(e.customWindDuration||180),T(e.customWindPauseDuration||15),ye(e.customDurationInSecondsToCompleteOneRevolution),Se(e.gmtOffset),Ce(e.dst)}},[e]);const nt=Gt(e?.currentTimeEpoch||0);if(t||!e)return i("div",{class:"settings-loading",children:[i("div",{class:"spinner"}),i("p",{children:n.settings.loading})]});if(e.winderEnabled===0)return null;const it=()=>{const u=h*z,Z=u/U*A,J=u+Z,dt=Math.floor(J/3600),ut=Math.floor(J%3600/60);return{hours:dt,mins:ut}},oe=(()=>{if(e.status!=="Winding")return 0;const{startTimeEpoch:u,currentTimeEpoch:$,estimatedRoutineFinishEpoch:Z}=e;if($>=Z)return 100;const J=($-u)/(Z-u);return Math.max(0,Math.min(100,J*100))})(),rt=e.db<=30?3:e.db<=60?2:1,se=u=>({action:u,rotationDirection:l,tpd:h,hour:m,minutes:b,timerEnabled:p?1:0,screenSleep:w,screenScheduleEnabled:g,screenScheduleStartTime:`${x.hour}:${x.minute}`,screenScheduleEndTime:`${W.hour}:${W.minute}`,customWindDuration:U,customWindPauseDuration:A,customDurationInSecondsToCompleteOneRevolution:z,rtcGmtOffset:we,rtcDST:re}),ot=async()=>{r(!0);try{const u=e.status==="Winding"?"START":"STOP";await B.updateSettings(se(u)),await o()}finally{r(!1)}},st=async()=>{r(!0);try{await B.updateSettings(se("START")),await o()}finally{r(!1)}},at=async()=>{r(!0);try{await B.updateSettings(se("STOP")),await o()}finally{r(!1)}},ke=it(),lt=e.status==="Winding"?n.settings.winding:n.settings.stopped,ct={CW:n.settings.clockwise,CCW:n.settings.counterClockwise,BOTH:n.settings.both},G=u=>({min:Math.floor(u/60),sec:u%60});return i("main",{class:"settings",children:[i("div",{class:`card status-card ${e.status.toLowerCase()}`,children:i("div",{class:"flex items-center justify-between",children:[i("div",{class:"flex items-center gap-2",children:[i("span",{class:`status-dot ${e.status.toLowerCase()}`}),i("span",{class:"font-medium",children:n.settings.status})]}),i("div",{class:"flex items-center gap-3",children:[i("span",{class:"font-semibold",children:lt}),i(E.Wifi,{bars:rt})]})]})}),i("div",{class:"card",children:i("div",{class:"control-buttons",children:[i("button",{class:"btn btn-success",onClick:st,disabled:a,children:[i(E.Play,{})," Start"]}),i("button",{class:"btn btn-danger",onClick:at,disabled:a,children:[i(E.Stop,{})," Stop"]})]})}),e.status==="Winding"&&i("div",{class:"card",children:[i("div",{class:"flex items-center justify-between mb-2",children:[i("span",{children:oe<5?n.settings.pleaseWait:n.settings.progress}),i("span",{class:"font-semibold",children:[Math.round(oe),"%"]})]}),i("div",{class:"progress",children:i("div",{class:"progress-bar",style:{width:`${oe}%`}})})]}),i("div",{class:"card",children:i("div",{class:"setting-row",children:[i("span",{children:n.settings.estimatedDuration}),i("span",{class:"setting-value",children:[ke.hours,"h ",ke.mins,"m"]})]})}),i("div",{class:"card",children:[i("div",{class:"setting-section",children:[i("label",{children:n.settings.direction}),i("div",{class:"setting-value mb-2",children:ct[l]}),i("div",{class:"direction-toggles",children:["CW","BOTH","CCW"].map(u=>i("button",{class:`dir-btn ${l===u?"active":""}`,onClick:()=>d(u),children:[u==="CW"&&i(E.RotateCW,{}),u==="CCW"&&i(E.RotateCCW,{}),u==="BOTH"&&i(E.Sync,{})]},u))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{children:n.settings.rotationsPerDay}),i("div",{class:"setting-value",children:h}),i("input",{type:"range",class:"slider",min:100,max:960,step:20,value:h,onInput:u=>c(Number(u.target.value))})]}),i("a",{href:"https://watch-winder.store/watch-winding-table/",target:"_blank",rel:"noopener",class:"btn btn-outline w-full mt-4",children:[i(E.ExternalLink,{}),n.settings.findWindingParameters]})]}),i("div",{class:"card",children:i("div",{class:"setting-section",children:[i("div",{class:"flex items-center justify-between",children:[i("label",{children:n.settings.cycleStart}),i("button",{class:`toggle ${p?"active":""}`,onClick:()=>s(!p)})]}),i("div",{class:"text-xs text-muted mt-1",children:p?n.settings.enabled.toUpperCase():n.settings.disabled.toUpperCase()}),p&&i("div",{class:"time-selects mt-3",children:[i("select",{class:"select",value:m,onChange:u=>_(u.target.value),children:ce.map(u=>i("option",{value:u,children:u},u))}),i("span",{class:"time-colon",children:":"}),i("select",{class:"select",value:b,onChange:u=>k(u.target.value),children:Jt.map(u=>i("option",{value:u,children:u},u))})]})]})}),e.screenEquipped&&i("div",{class:"card",children:[i("div",{class:"setting-section",children:[i("div",{class:"flex items-center justify-between",children:[i("label",{class:"flex items-center gap-2",children:[i(E.Display,{}),n.settings.screen]}),i("button",{class:`toggle ${w?"":"active"}`,onClick:()=>f(!w)})]}),i("div",{class:"text-xs text-muted mt-1",children:w?n.settings.disabled.toUpperCase():n.settings.enabled.toUpperCase()})]}),i("div",{class:"setting-section mt-4",children:[i("div",{class:"flex items-center justify-between",children:[i("label",{children:n.settings.screenSchedule}),i("button",{class:`toggle ${g?"active":""}`,onClick:()=>P(!g)})]}),g&&i("div",{class:"schedule-times mt-3",children:[i("div",{class:"schedule-row",children:[i("span",{class:"text-sm",children:n.settings.turnOnScreenAt}),i("div",{class:"time-selects",children:[i("select",{class:"select",value:x.hour,onChange:u=>H({...x,hour:u.target.value}),children:ce.map(u=>i("option",{value:u,children:u},u))}),i("span",{class:"time-colon",children:":"}),i("select",{class:"select",value:x.minute,onChange:u=>H({...x,minute:u.target.value}),children:$e.map(u=>i("option",{value:u,children:u},u))})]})]}),i("div",{class:"schedule-row",children:[i("span",{class:"text-sm",children:n.settings.turnOffScreenAt}),i("div",{class:"time-selects",children:[i("select",{class:"select",value:W.hour,onChange:u=>M({...W,hour:u.target.value}),children:ce.map(u=>i("option",{value:u,children:u},u))}),i("span",{class:"time-colon",children:":"}),i("select",{class:"select",value:W.minute,onChange:u=>M({...W,minute:u.target.value}),children:$e.map(u=>i("option",{value:u,children:u},u))})]})]})]})]})]}),i("div",{class:"card",children:[i("h3",{class:"flex items-center gap-2 mb-4",children:[i(E.Settings,{}),n.settings.customize]}),i("div",{class:"setting-section",children:[i("label",{children:n.settings.rotationDurationTime}),i("div",{class:"setting-value",children:[G(U).min,"m ",G(U).sec,"s"]}),i("input",{type:"range",class:"slider",min:100,max:960,step:10,value:U,onInput:u=>L(Number(u.target.value))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{children:n.settings.rotationPauseTime}),i("div",{class:"setting-value",children:[G(A).min,"m ",G(A).sec,"s"]}),i("input",{type:"range",class:"slider",min:10,max:900,step:5,value:A,onInput:u=>T(Number(u.target.value))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{children:n.settings.singleRotationTiming}),i("div",{class:"setting-value",children:[z," ",n.settings.seconds]}),i("input",{type:"range",class:"slider",min:1,max:16,step:1,value:z,onInput:u=>ye(Number(u.target.value))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{class:"flex items-center gap-2",children:[i(E.Clock,{}),n.settings.internalClock]}),i("div",{class:"setting-value",children:Zt(nt)}),i("p",{class:"text-xs text-muted mt-2",children:n.settings.internalClockBlurb}),i("div",{class:"mt-3",children:[i("label",{class:"text-sm",children:n.settings.utcOffset}),i("select",{class:"select w-full mt-1",value:we,onChange:u=>Se(Number(u.target.value)),children:Kt.map(u=>i("option",{value:u.value,children:u.label},u.value))})]}),i("div",{class:"flex items-center justify-between mt-3",children:[i("label",{children:n.settings.dst}),i("button",{class:`toggle ${re?"active":""}`,onClick:()=>Ce(!re)})]})]})]}),i("div",{class:"card",children:i("button",{class:"btn btn-primary w-full",onClick:ot,disabled:a,children:a?n.settings.saveInProgress:n.settings.save})}),i("style",{children:`
        .settings {
          max-width: 600px;
          margin: 0 auto;
          padding: 1rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
          padding-bottom: 2rem;
        }

        .settings-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 60vh;
          gap: 1rem;
        }

        .spinner {
          width: 40px;
          height: 40px;
          border: 3px solid var(--border);
          border-top-color: var(--accent);
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        .status-card.winding {
          border-color: var(--success);
          box-shadow: 0 0 20px var(--success-glow);
        }

        .status-card.stopped {
          border-color: var(--danger);
        }

        .control-buttons {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .setting-section {
          padding-bottom: 1rem;
          border-bottom: 1px solid var(--border);
        }

        .setting-section:last-child {
          border-bottom: none;
          padding-bottom: 0;
        }

        .setting-section label {
          font-weight: 500;
          color: var(--text-secondary);
          font-size: 0.875rem;
        }

        .setting-value {
          font-size: 1.25rem;
          font-weight: 600;
          color: var(--text-primary);
          margin: 0.25rem 0;
        }

        .setting-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .direction-toggles {
          display: flex;
          gap: 0.5rem;
        }

        .dir-btn {
          flex: 1;
          padding: 0.75rem;
          border: 2px solid var(--border);
          border-radius: var(--radius-md);
          transition: var(--transition);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .dir-btn:hover {
          border-color: var(--accent);
          color: var(--accent);
        }

        .dir-btn.active {
          background: var(--accent);
          border-color: var(--accent);
          color: white;
        }

        .time-selects {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .time-selects .select {
          width: 80px;
        }

        .time-colon {
          font-size: 1.25rem;
          font-weight: 600;
        }

        .schedule-times {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .schedule-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        @media (max-width: 400px) {
          .control-buttons {
            grid-template-columns: 1fr;
          }
          
          .schedule-row {
            flex-direction: column;
            align-items: flex-start;
          }
        }
      `})]})}function Xt(){return i(qt,{children:[i(Vt,{}),i(Qt,{})]})}vt(i(Xt,{}),document.getElementById("app"));
