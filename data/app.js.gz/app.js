(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))s(o);new MutationObserver(o=>{for(const r of o)if(r.type==="childList")for(const l of r.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&s(l)}).observe(document,{childList:!0,subtree:!0});function n(o){const r={};return o.integrity&&(r.integrity=o.integrity),o.referrerPolicy&&(r.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?r.credentials="include":o.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(o){if(o.ep)return;o.ep=!0;const r=n(o);fetch(o.href,r)}})();var te,b,Le,R,Te,Oe,Fe,Ne,me,de,ue,Ie,V={},je=[],_t=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,ne=Array.isArray;function M(e,t){for(var n in t)e[n]=t[n];return e}function fe(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ht(e,t,n){var s,o,r,l={};for(r in t)r=="key"?s=t[r]:r=="ref"?o=t[r]:l[r]=t[r];if(arguments.length>2&&(l.children=arguments.length>3?te.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)l[r]===void 0&&(l[r]=e.defaultProps[r]);return Q(e,l,s,o,null)}function Q(e,t,n,s,o){var r={type:e,props:t,key:n,ref:s,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++Le,__i:-1,__u:0};return o==null&&b.vnode!=null&&b.vnode(r),r}function I(e){return e.children}function X(e,t){this.props=e,this.context=t}function F(e,t){if(t==null)return e.__?F(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?F(e):null}function Ve(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Ve(e)}}function _e(e){(!e.__d&&(e.__d=!0)&&R.push(e)&&!ee.__r++||Te!=b.debounceRendering)&&((Te=b.debounceRendering)||Oe)(ee)}function ee(){for(var e,t,n,s,o,r,l,d=1;R.length;)R.length>d&&R.sort(Fe),e=R.shift(),d=R.length,e.__d&&(n=void 0,s=void 0,o=(s=(t=e).__v).__e,r=[],l=[],t.__P&&((n=M({},s)).__v=s.__v+1,b.vnode&&b.vnode(n),ge(t.__P,n,s,t.__n,t.__P.namespaceURI,32&s.__u?[o]:null,r,o??F(s),!!(32&s.__u),l),n.__v=s.__v,n.__.__k[n.__i]=n,Ze(r,n,l),s.__e=s.__=null,n.__e!=o&&Ve(n)));ee.__r=0}function qe(e,t,n,s,o,r,l,d,h,c,p){var a,m,_,g,x,w,v,f=s&&s.__k||je,D=t.length;for(h=pt(n,t,f,h,D),a=0;a<D;a++)(_=n.__k[a])!=null&&(m=_.__i==-1?V:f[_.__i]||V,_.__i=a,w=ge(e,_,m,o,r,l,d,h,c,p),g=_.__e,_.ref&&m.ref!=_.ref&&(m.ref&&ve(m.ref,null,_),p.push(_.ref,_.__c||g,_)),x==null&&g!=null&&(x=g),(v=!!(4&_.__u))||m.__k===_.__k?h=Ge(_,h,e,v):typeof _.type=="function"&&w!==void 0?h=w:g&&(h=g.nextSibling),_.__u&=-7);return n.__e=x,h}function pt(e,t,n,s,o){var r,l,d,h,c,p=n.length,a=p,m=0;for(e.__k=new Array(o),r=0;r<o;r++)(l=t[r])!=null&&typeof l!="boolean"&&typeof l!="function"?(typeof l=="string"||typeof l=="number"||typeof l=="bigint"||l.constructor==String?l=e.__k[r]=Q(null,l,null,null,null):ne(l)?l=e.__k[r]=Q(I,{children:l},null,null,null):l.constructor==null&&l.__b>0?l=e.__k[r]=Q(l.type,l.props,l.key,l.ref?l.ref:null,l.__v):e.__k[r]=l,h=r+m,l.__=e,l.__b=e.__b+1,d=null,(c=l.__i=mt(l,n,h,a))!=-1&&(a--,(d=n[c])&&(d.__u|=2)),d==null||d.__v==null?(c==-1&&(o>p?m--:o<p&&m++),typeof l.type!="function"&&(l.__u|=4)):c!=h&&(c==h-1?m--:c==h+1?m++:(c>h?m--:m++,l.__u|=4))):e.__k[r]=null;if(a)for(r=0;r<p;r++)(d=n[r])!=null&&(2&d.__u)==0&&(d.__e==s&&(s=F(d)),Ke(d,d));return s}function Ge(e,t,n,s){var o,r;if(typeof e.type=="function"){for(o=e.__k,r=0;o&&r<o.length;r++)o[r]&&(o[r].__=e,t=Ge(o[r],t,n,s));return t}e.__e!=t&&(s&&(t&&e.type&&!t.parentNode&&(t=F(e)),n.insertBefore(e.__e,t||null)),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function mt(e,t,n,s){var o,r,l,d=e.key,h=e.type,c=t[n],p=c!=null&&(2&c.__u)==0;if(c===null&&d==null||p&&d==c.key&&h==c.type)return n;if(s>(p?1:0)){for(o=n-1,r=n+1;o>=0||r<t.length;)if((c=t[l=o>=0?o--:r++])!=null&&(2&c.__u)==0&&d==c.key&&h==c.type)return l}return-1}function ze(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||_t.test(t)?n:n+"px"}function K(e,t,n,s,o){var r,l;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof s=="string"&&(e.style.cssText=s=""),s)for(t in s)n&&t in n||ze(e.style,t,"");if(n)for(t in n)s&&n[t]==s[t]||ze(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(Ne,"$1")),l=t.toLowerCase(),t=l in e||t=="onFocusOut"||t=="onFocusIn"?l.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?s?n.u=s.u:(n.u=me,e.addEventListener(t,r?ue:de,r)):e.removeEventListener(t,r?ue:de,r);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Ee(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=me++;else if(t.t<n.u)return;return n(b.event?b.event(t):t)}}}function ge(e,t,n,s,o,r,l,d,h,c){var p,a,m,_,g,x,w,v,f,D,z,B,W,L,U,A,H,E=t.type;if(t.constructor!=null)return null;128&n.__u&&(h=!!(32&n.__u),r=[d=t.__e=n.__e]),(p=b.__b)&&p(t);e:if(typeof E=="function")try{if(v=t.props,f="prototype"in E&&E.prototype.render,D=(p=E.contextType)&&s[p.__c],z=p?D?D.props.value:p.__:s,n.__c?w=(a=t.__c=n.__c).__=a.__E:(f?t.__c=a=new E(v,z):(t.__c=a=new X(v,z),a.constructor=E,a.render=gt),D&&D.sub(a),a.state||(a.state={}),a.__n=s,m=a.__d=!0,a.__h=[],a._sb=[]),f&&a.__s==null&&(a.__s=a.state),f&&E.getDerivedStateFromProps!=null&&(a.__s==a.state&&(a.__s=M({},a.__s)),M(a.__s,E.getDerivedStateFromProps(v,a.__s))),_=a.props,g=a.state,a.__v=t,m)f&&E.getDerivedStateFromProps==null&&a.componentWillMount!=null&&a.componentWillMount(),f&&a.componentDidMount!=null&&a.__h.push(a.componentDidMount);else{if(f&&E.getDerivedStateFromProps==null&&v!==_&&a.componentWillReceiveProps!=null&&a.componentWillReceiveProps(v,z),t.__v==n.__v||!a.__e&&a.shouldComponentUpdate!=null&&a.shouldComponentUpdate(v,a.__s,z)===!1){for(t.__v!=n.__v&&(a.props=v,a.state=a.__s,a.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(P){P&&(P.__=t)}),B=0;B<a._sb.length;B++)a.__h.push(a._sb[B]);a._sb=[],a.__h.length&&l.push(a);break e}a.componentWillUpdate!=null&&a.componentWillUpdate(v,a.__s,z),f&&a.componentDidUpdate!=null&&a.__h.push(function(){a.componentDidUpdate(_,g,x)})}if(a.context=z,a.props=v,a.__P=e,a.__e=!1,W=b.__r,L=0,f){for(a.state=a.__s,a.__d=!1,W&&W(t),p=a.render(a.props,a.state,a.context),U=0;U<a._sb.length;U++)a.__h.push(a._sb[U]);a._sb=[]}else do a.__d=!1,W&&W(t),p=a.render(a.props,a.state,a.context),a.state=a.__s;while(a.__d&&++L<25);a.state=a.__s,a.getChildContext!=null&&(s=M(M({},s),a.getChildContext())),f&&!m&&a.getSnapshotBeforeUpdate!=null&&(x=a.getSnapshotBeforeUpdate(_,g)),A=p,p!=null&&p.type===I&&p.key==null&&(A=Je(p.props.children)),d=qe(e,ne(A)?A:[A],t,n,s,o,r,l,d,h,c),a.base=t.__e,t.__u&=-161,a.__h.length&&l.push(a),w&&(a.__E=a.__=null)}catch(P){if(t.__v=null,h||r!=null)if(P.then){for(t.__u|=h?160:128;d&&d.nodeType==8&&d.nextSibling;)d=d.nextSibling;r[r.indexOf(d)]=null,t.__e=d}else{for(H=r.length;H--;)fe(r[H]);he(t)}else t.__e=n.__e,t.__k=n.__k,P.then||he(t);b.__e(P,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):d=t.__e=ft(n.__e,t,n,s,o,r,l,h,c);return(p=b.diffed)&&p(t),128&t.__u?void 0:d}function he(e){e&&e.__c&&(e.__c.__e=!0),e&&e.__k&&e.__k.forEach(he)}function Ze(e,t,n){for(var s=0;s<n.length;s++)ve(n[s],n[++s],n[++s]);b.__c&&b.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(r){r.call(o)})}catch(r){b.__e(r,o.__v)}})}function Je(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:ne(e)?e.map(Je):M({},e)}function ft(e,t,n,s,o,r,l,d,h){var c,p,a,m,_,g,x,w=n.props||V,v=t.props,f=t.type;if(f=="svg"?o="http://www.w3.org/2000/svg":f=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),r!=null){for(c=0;c<r.length;c++)if((_=r[c])&&"setAttribute"in _==!!f&&(f?_.localName==f:_.nodeType==3)){e=_,r[c]=null;break}}if(e==null){if(f==null)return document.createTextNode(v);e=document.createElementNS(o,f,v.is&&v),d&&(b.__m&&b.__m(t,r),d=!1),r=null}if(f==null)w===v||d&&e.data==v||(e.data=v);else{if(r=r&&te.call(e.childNodes),!d&&r!=null)for(w={},c=0;c<e.attributes.length;c++)w[(_=e.attributes[c]).name]=_.value;for(c in w)if(_=w[c],c!="children"){if(c=="dangerouslySetInnerHTML")a=_;else if(!(c in v)){if(c=="value"&&"defaultValue"in v||c=="checked"&&"defaultChecked"in v)continue;K(e,c,null,_,o)}}for(c in v)_=v[c],c=="children"?m=_:c=="dangerouslySetInnerHTML"?p=_:c=="value"?g=_:c=="checked"?x=_:d&&typeof _!="function"||w[c]===_||K(e,c,_,w[c],o);if(p)d||a&&(p.__html==a.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(a&&(e.innerHTML=""),qe(t.type=="template"?e.content:e,ne(m)?m:[m],t,n,s,f=="foreignObject"?"http://www.w3.org/1999/xhtml":o,r,l,r?r[0]:n.__k&&F(n,0),d,h),r!=null)for(c=r.length;c--;)fe(r[c]);d||(c="value",f=="progress"&&g==null?e.removeAttribute("value"):g!=null&&(g!==e[c]||f=="progress"&&!g||f=="option"&&g!=w[c])&&K(e,c,g,w[c],o),c="checked",x!=null&&x!=e[c]&&K(e,c,x,w[c],o))}return e}function ve(e,t,n){try{if(typeof e=="function"){var s=typeof e.__u=="function";s&&e.__u(),s&&t==null||(e.__u=e(t))}else e.current=t}catch(o){b.__e(o,n)}}function Ke(e,t,n){var s,o;if(b.unmount&&b.unmount(e),(s=e.ref)&&(s.current&&s.current!=e.__e||ve(s,null,t)),(s=e.__c)!=null){if(s.componentWillUnmount)try{s.componentWillUnmount()}catch(r){b.__e(r,t)}s.base=s.__P=null}if(s=e.__k)for(o=0;o<s.length;o++)s[o]&&Ke(s[o],t,n||typeof e.type!="function");n||fe(e.__e),e.__c=e.__=e.__e=void 0}function gt(e,t,n){return this.constructor(e,n)}function vt(e,t,n){var s,o,r,l;t==document&&(t=document.documentElement),b.__&&b.__(e,t),o=(s=!1)?null:t.__k,r=[],l=[],ge(t,e=t.__k=ht(I,null,[e]),o||V,V,t.namespaceURI,o?null:t.firstChild?te.call(t.childNodes):null,r,o?o.__e:t.firstChild,s,l),Ze(r,e,l)}function bt(e){function t(n){var s,o;return this.getChildContext||(s=new Set,(o={})[t.__c]=this,this.getChildContext=function(){return o},this.componentWillUnmount=function(){s=null},this.shouldComponentUpdate=function(r){this.props.value!=r.value&&s.forEach(function(l){l.__e=!0,_e(l)})},this.sub=function(r){s.add(r);var l=r.componentWillUnmount;r.componentWillUnmount=function(){s&&s.delete(r),l&&l.call(r)}}),n.children}return t.__c="__cC"+Ie++,t.__=e,t.Provider=t.__l=(t.Consumer=function(n,s){return n.children(s)}).contextType=t,t}te=je.slice,b={__e:function(e,t,n,s){for(var o,r,l;t=t.__;)if((o=t.__c)&&!o.__)try{if((r=o.constructor)&&r.getDerivedStateFromError!=null&&(o.setState(r.getDerivedStateFromError(e)),l=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,s||{}),l=o.__d),l)return o.__E=o}catch(d){e=d}throw e}},Le=0,X.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=M({},this.state),typeof e=="function"&&(e=e(M({},n),this.props)),e&&M(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),_e(this))},X.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),_e(this))},X.prototype.render=I,R=[],Oe=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Fe=function(e,t){return e.__v.__b-t.__v.__b},ee.__r=0,Ne=/(PointerCapture)$|Capture$/i,me=0,de=Ee(!1),ue=Ee(!0),Ie=0;var yt=0;function i(e,t,n,s,o,r){t||(t={});var l,d,h=t;if("ref"in h)for(d in h={},t)d=="ref"?l=t[d]:h[d]=t[d];var c={type:e,props:h,key:n,ref:l,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--yt,__i:-1,__u:0,__source:o,__self:r};if(typeof e=="function"&&(l=e.defaultProps))for(d in l)h[d]===void 0&&(h[d]=l[d]);return b.vnode&&b.vnode(c),c}var N,y,ae,We,q=0,Qe=[],S=b,De=S.__b,Pe=S.__r,Ue=S.diffed,He=S.__c,Me=S.unmount,Be=S.__;function ie(e,t){S.__h&&S.__h(y,e,q||t),q=0;var n=y.__H||(y.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function C(e){return q=1,wt(et,e)}function wt(e,t,n){var s=ie(N++,2);if(s.t=e,!s.__c&&(s.__=[et(void 0,t),function(d){var h=s.__N?s.__N[0]:s.__[0],c=s.t(h,d);h!==c&&(s.__N=[c,s.__[1]],s.__c.setState({}))}],s.__c=y,!y.__f)){var o=function(d,h,c){if(!s.__c.__H)return!0;var p=s.__c.__H.__.filter(function(m){return!!m.__c});if(p.every(function(m){return!m.__N}))return!r||r.call(this,d,h,c);var a=s.__c.props!==d;return p.forEach(function(m){if(m.__N){var _=m.__[0];m.__=m.__N,m.__N=void 0,_!==m.__[0]&&(a=!0)}}),r&&r.call(this,d,h,c)||a};y.__f=!0;var r=y.shouldComponentUpdate,l=y.componentWillUpdate;y.componentWillUpdate=function(d,h,c){if(this.__e){var p=r;r=void 0,o(d,h,c),r=p}l&&l.call(this,d,h,c)},y.shouldComponentUpdate=o}return s.__N||s.__}function be(e,t){var n=ie(N++,3);!S.__s&&Ye(n.__H,t)&&(n.__=e,n.u=t,y.__H.__h.push(n))}function Ct(e){return q=5,Xe(function(){return{current:e}},[])}function Xe(e,t){var n=ie(N++,7);return Ye(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function le(e,t){return q=8,Xe(function(){return e},t)}function St(e){var t=y.context[e.__c],n=ie(N++,9);return n.c=e,t?(n.__==null&&(n.__=!0,t.sub(y)),t.props.value):e.__}function xt(){for(var e;e=Qe.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(Y),e.__H.__h.forEach(pe),e.__H.__h=[]}catch(t){e.__H.__h=[],S.__e(t,e.__v)}}S.__b=function(e){y=null,De&&De(e)},S.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Be&&Be(e,t)},S.__r=function(e){Pe&&Pe(e),N=0;var t=(y=e.__c).__H;t&&(ae===y?(t.__h=[],y.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(Y),t.__h.forEach(pe),t.__h=[],N=0)),ae=y},S.diffed=function(e){Ue&&Ue(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(Qe.push(t)!==1&&We===S.requestAnimationFrame||((We=S.requestAnimationFrame)||kt)(xt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),ae=y=null},S.__c=function(e,t){t.some(function(n){try{n.__h.forEach(Y),n.__h=n.__h.filter(function(s){return!s.__||pe(s)})}catch(s){t.some(function(o){o.__h&&(o.__h=[])}),t=[],S.__e(s,n.__v)}}),He&&He(e,t)},S.unmount=function(e){Me&&Me(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(s){try{Y(s)}catch(o){t=o}}),n.__H=void 0,t&&S.__e(t,n.__v))};var Ae=typeof requestAnimationFrame=="function";function kt(e){var t,n=function(){clearTimeout(s),Ae&&cancelAnimationFrame(t),setTimeout(e)},s=setTimeout(n,35);Ae&&(t=requestAnimationFrame(n))}function Y(e){var t=y,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),y=t}function pe(e){var t=y;e.__c=e.__(),y=t}function Ye(e,t){return!e||e.length!==t.length||t.some(function(n,s){return n!==e[s]})}function et(e,t){return typeof t=="function"?t(e):t}function Tt(){const e=window.location.href;return e.includes("127.0.0.1")||e.includes("localhost")?"http://192.168.4.1/api/":(e.endsWith("/")?e.slice(0,-1):e)+"/api/"}const zt=Tt();async function j(e,t){const n=await fetch(zt+e,{...t,headers:{"Content-Type":"application/json",...t?.headers}});if(!n.ok)throw new Error(`HTTP ${n.status}`);return n.status===204?{}:n.json()}const O={getStatus:()=>j("status"),updatePower:e=>j("power",{method:"POST",body:JSON.stringify({winderEnabled:e?1:0})}),updateTimer:e=>j(`timer?timerEnabled=${e?1:0}`,{method:"POST"}),updateSettings:e=>j("update",{method:"POST",body:JSON.stringify(e)}),reset:()=>j("reset")},Et={motor:"Motor",wifi:"WiFi",screen:"Screen",firmware:"Firmware",connected:"Connected",notConnected:"Not Connected"},Wt={reset:"Reset",on:"on",off:"off",dialog:{title:"Reset takes 20 seconds",subtitle:"This screen will not close during the reset process",cancel:"Cancel",point1:"Reset is complete when the second LED stops fast blinking, then turns solid.",point2:"Connect your mobile device to the new WiFi network called",point3:"Add Winderoo to an existing WiFi network. If the LED starts to slow blink, Winderoo has successfully joined that network.",point4:"Wait for your device to reconnect to your existing WiFi network.",nowAvailable:"Winderoo is now available at:",confirmReset:"Confirm Reset"}},Dt={status:"Status",stopped:"Stopped",winding:"Winding",estimatedDuration:"Estimated Cycle Duration",direction:"Direction",rotationsPerDay:"Rotations Per Day",findWindingParameters:"Find your watch's winding parameters",cycleStart:"Cycle Start Time",enabled:"Enabled",disabled:"Disabled",hours:"Hour",minutes:"Minutes",save:"Save",saveInProgress:"Saving...",clockwise:"Clockwise",counterClockwise:"Counter Clockwise",both:"Both",pleaseWait:"Getting cycle progress...",progress:"Cycle Progress",screen:"OLED Screen",screenSchedule:"Screen Schedule",enableSchedule:"Enable Schedule",turnOnScreenAt:"Turn On At",turnOffScreenAt:"Turn Off At",customize:"Settings & Customization",rotationDurationTime:"Time to rotate",rotationPauseTime:"Time to pause",seconds:"seconds",internalClock:"Internal Clock",internalClockBlurb:"Winderoo has an internal clock (RTC), which is automatically set during boot.",internalClockBlurb2:"If this is incorrect, please update the clock beneath.",utcOffset:"UTC Offset",dst:"Daylight Savings Time",loading:"Loading...",singleRotationTiming:"Time for one rotation"},Pt={statusBar:Et,header:Wt,settings:Dt},Ut={motor:"Motor",wifi:"WLAN",screen:"Bildschirm",firmware:"Firmware",connected:"Verbunden",notConnected:"Nicht verbunden"},Ht={reset:"Zurücksetzen",on:"an",off:"aus",dialog:{title:"Das Zurücksetzen dauert 20 Sekunden",subtitle:"Dieser Bildschirm wird während des Zurücksetzens nicht geschlossen",cancel:"Abbrechen",point1:"Das Zurücksetzen ist abgeschlossen, wenn die zweite LED aufhört schnell zu blinken und dann durchgehend leuchtet.",point2:"Verbinden Sie Ihr Mobilgerät mit dem neuen WiFi-Netzwerk namens",point3:"Fügen Sie Winderoo einem bestehenden WiFi-Netzwerk hinzu. Wenn die LED langsam zu blinken beginnt, hat Winderoo erfolgreich das Netzwerk beigetreten.",point4:"Warten Sie, bis Ihr Gerät sich wieder mit Ihrem bestehenden WiFi-Netzwerk verbindet.",nowAvailable:"Winderoo ist jetzt verfügbar unter:",confirmReset:"Zurücksetzen bestätigen"}},Mt={status:"Status",stopped:"Gestoppt",winding:"Aufziehend",estimatedDuration:"Geschätzte Zyklusdauer",direction:"Richtung",rotationsPerDay:"Umdrehungen pro Tag",findWindingParameters:"Finden Sie die Aufziehparameter Ihrer Uhr",cycleStart:"Zyklus-Startzeit",enabled:"Aktiviert",disabled:"Deaktiviert",hours:"Stunde",minutes:"Minuten",save:"Speichern",saveInProgress:"Speichern...",clockwise:"Im Uhrzeigersinn",counterClockwise:"Gegen den Uhrzeigersinn",both:"Beide",pleaseWait:"Zyklusfortschritt wird geladen...",progress:"Zyklusfortschritt",screen:"OLED-Bildschirm",screenSchedule:"Bildschirmzeitplan",enableSchedule:"Zeitplan aktivieren",turnOnScreenAt:"Einschalten um",turnOffScreenAt:"Ausschalten um",customize:"Einstellungen & Anpassung",rotationDurationTime:"Rotationsdauer",rotationPauseTime:"Pausenzeit",seconds:"Sekunden",internalClock:"Interne Uhr",internalClockBlurb:"Winderoo hat eine interne Uhr (RTC), die beim Start automatisch eingestellt wird.",internalClockBlurb2:"Wenn dies nicht korrekt ist, aktualisieren Sie bitte die Uhr unten.",utcOffset:"UTC-Versatz",dst:"Sommerzeit",loading:"Laden...",singleRotationTiming:"Zeit für eine Umdrehung"},Bt={statusBar:Ut,header:Ht,settings:Mt},At={motor:"Motor",wifi:"WiFi",screen:"Pantalla",firmware:"Firmware",connected:"Conectado",notConnected:"No conectado"},$t={reset:"Reiniciar",on:"encendido",off:"apagado",dialog:{title:"El reinicio tarda 20 segundos",subtitle:"Esta pantalla no se cerrará durante el proceso de reinicio",cancel:"Cancelar",point1:"El reinicio está completo cuando el segundo LED deja de parpadear rápido y luego se queda fijo.",point2:"Conecte su dispositivo móvil a la nueva red WiFi llamada",point3:"Agregue Winderoo a una red WiFi existente. Si el LED comienza a parpadear lentamente, Winderoo se ha unido exitosamente a esa red.",point4:"Espere a que su dispositivo se reconecte a su red WiFi existente.",nowAvailable:"Winderoo está ahora disponible en:",confirmReset:"Confirmar Reinicio"}},Rt={status:"Estado",stopped:"Detenido",winding:"En marcha",estimatedDuration:"Duración estimada del ciclo",direction:"Dirección",rotationsPerDay:"Rotaciones por día",findWindingParameters:"Encuentra los parámetros de cuerda de tu reloj",cycleStart:"Hora de inicio del ciclo",enabled:"Habilitado",disabled:"Deshabilitado",hours:"Hora",minutes:"Minutos",save:"Guardar",saveInProgress:"Guardando...",clockwise:"Sentido horario",counterClockwise:"Sentido antihorario",both:"Ambos",pleaseWait:"Obteniendo progreso del ciclo...",progress:"Progreso del ciclo",screen:"Pantalla OLED",screenSchedule:"Programación de pantalla",enableSchedule:"Habilitar programación",turnOnScreenAt:"Encender a las",turnOffScreenAt:"Apagar a las",customize:"Configuración y personalización",rotationDurationTime:"Tiempo de rotación",rotationPauseTime:"Tiempo de pausa",seconds:"segundos",internalClock:"Reloj interno",internalClockBlurb:"Winderoo tiene un reloj interno (RTC), que se configura automáticamente durante el arranque.",internalClockBlurb2:"Si esto es incorrecto, actualice el reloj a continuación.",utcOffset:"Desplazamiento UTC",dst:"Horario de verano",loading:"Cargando...",singleRotationTiming:"Tiempo para una rotación"},Lt={statusBar:At,header:$t,settings:Rt},Ot={motor:"Moteur",wifi:"WiFi",screen:"Écran",firmware:"Firmware",connected:"Connecté",notConnected:"Non connecté"},Ft={reset:"Réinitialiser",on:"activé",off:"désactivé",dialog:{title:"La réinitialisation prend 20 secondes",subtitle:"Cet écran ne se fermera pas pendant le processus de réinitialisation",cancel:"Annuler",point1:"La réinitialisation est terminée lorsque la deuxième LED arrête de clignoter rapidement, puis reste allumée.",point2:"Connectez votre appareil mobile au nouveau réseau WiFi appelé",point3:"Ajoutez Winderoo à un réseau WiFi existant. Si la LED commence à clignoter lentement, Winderoo a rejoint ce réseau avec succès.",point4:"Attendez que votre appareil se reconnecte à votre réseau WiFi existant.",nowAvailable:"Winderoo est maintenant disponible à:",confirmReset:"Confirmer la réinitialisation"}},Nt={status:"Statut",stopped:"Arrêté",winding:"En marche",estimatedDuration:"Durée estimée du cycle",direction:"Direction",rotationsPerDay:"Rotations par jour",findWindingParameters:"Trouvez les paramètres de remontage de votre montre",cycleStart:"Heure de début du cycle",enabled:"Activé",disabled:"Désactivé",hours:"Heure",minutes:"Minutes",save:"Enregistrer",saveInProgress:"Enregistrement...",clockwise:"Sens horaire",counterClockwise:"Sens antihoraire",both:"Les deux",pleaseWait:"Obtention de la progression du cycle...",progress:"Progression du cycle",screen:"Écran OLED",screenSchedule:"Programmation de l'écran",enableSchedule:"Activer la programmation",turnOnScreenAt:"Allumer à",turnOffScreenAt:"Éteindre à",customize:"Paramètres et personnalisation",rotationDurationTime:"Durée de rotation",rotationPauseTime:"Durée de pause",seconds:"secondes",internalClock:"Horloge interne",internalClockBlurb:"Winderoo possède une horloge interne (RTC), qui est automatiquement réglée au démarrage.",internalClockBlurb2:"Si c'est incorrect, veuillez mettre à jour l'horloge ci-dessous.",utcOffset:"Décalage UTC",dst:"Heure d'été",loading:"Chargement...",singleRotationTiming:"Temps pour une rotation"},It={statusBar:Ot,header:Ft,settings:Nt},jt={motor:"Motor",wifi:"WiFi",screen:"Tela",firmware:"Firmware",connected:"Conectado",notConnected:"Não conectado"},Vt={reset:"Reiniciar",on:"ligado",off:"desligado",dialog:{title:"A reinicialização leva 20 segundos",subtitle:"Esta tela não fechará durante o processo de reinicialização",cancel:"Cancelar",point1:"A reinicialização está completa quando o segundo LED para de piscar rapidamente e fica fixo.",point2:"Conecte seu dispositivo móvel à nova rede WiFi chamada",point3:"Adicione Winderoo a uma rede WiFi existente. Se o LED começar a piscar lentamente, Winderoo entrou com sucesso nessa rede.",point4:"Aguarde seu dispositivo se reconectar à sua rede WiFi existente.",nowAvailable:"Winderoo está agora disponível em:",confirmReset:"Confirmar Reinicialização"}},qt={status:"Status",stopped:"Parado",winding:"Girando",estimatedDuration:"Duração estimada do ciclo",direction:"Direção",rotationsPerDay:"Rotações por dia",findWindingParameters:"Encontre os parâmetros de corda do seu relógio",cycleStart:"Hora de início do ciclo",enabled:"Habilitado",disabled:"Desabilitado",hours:"Hora",minutes:"Minutos",save:"Salvar",saveInProgress:"Salvando...",clockwise:"Sentido horário",counterClockwise:"Sentido anti-horário",both:"Ambos",pleaseWait:"Obtendo progresso do ciclo...",progress:"Progresso do ciclo",screen:"Tela OLED",screenSchedule:"Agendamento de tela",enableSchedule:"Habilitar agendamento",turnOnScreenAt:"Ligar às",turnOffScreenAt:"Desligar às",customize:"Configurações e personalização",rotationDurationTime:"Tempo de rotação",rotationPauseTime:"Tempo de pausa",seconds:"segundos",internalClock:"Relógio interno",internalClockBlurb:"Winderoo possui um relógio interno (RTC), que é configurado automaticamente durante a inicialização.",internalClockBlurb2:"Se estiver incorreto, atualize o relógio abaixo.",utcOffset:"Deslocamento UTC",dst:"Horário de verão",loading:"Carregando...",singleRotationTiming:"Tempo para uma rotação"},Gt={statusBar:jt,header:Vt,settings:qt},$e={"en-US":Pt,"de-DE":Bt,"es-ES":Lt,"fr-FR":It,"pt-BR":Gt},Zt=[{code:"en-US",name:"English"},{code:"de-DE",name:"Deutsch"},{code:"es-ES",name:"Español"},{code:"fr-FR",name:"Français"},{code:"pt-BR",name:"Português"}];function Jt(e){return $e[e]||$e["en-US"]}const tt=bt(null);function Kt({children:e}){const[t,n]=C(null),[s,o]=C(!0),[r,l]=C(null),[d,h]=C(()=>localStorage.getItem("selectedLanguage")||"en-US"),c=Jt(d),p=le(_=>{h(_),localStorage.setItem("selectedLanguage",_)},[]),a=le(async()=>{try{o(!0),l(null);const _=await O.getStatus();_.db=Math.abs(_.db),n(_)}catch(_){l(_ instanceof Error?_.message:"Failed to fetch status")}finally{o(!1)}},[]),m=le(async _=>{n(g=>g&&{...g,winderEnabled:_?1:0});try{await O.updatePower(_),await new Promise(g=>setTimeout(g,200)),await a()}catch(g){n(x=>x&&{...x,winderEnabled:_?0:1}),l(g instanceof Error?g.message:"Failed to update power")}},[a]);return be(()=>{a()},[a]),i(tt.Provider,{value:{status:t,loading:s,error:r,language:d,translations:c,setLanguage:p,refresh:a,setPower:m},children:e})}function ye(){const e=St(tt);if(!e)throw new Error("useStore must be used within StoreProvider");return e}const k={width:"20px",height:"20px",fill:"currentColor"},T={Watch:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"})}),Bolt:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66.19-.34.05-.08.07-.12C8.48 10.94 10.42 7.54 13 3h1l-1 7h3.5c.49 0 .56.33.47.51l-.07.15C12.96 17.55 11 21 11 21z"})}),Globe:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"})}),Play:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M8 5v14l11-7z"})}),Stop:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M6 6h12v12H6z"})}),RotateCW:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"})}),RotateCCW:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M12 4V1l4 4-4 4V6c-3.31 0-6 2.69-6 6 0 1.01.25 1.97.7 2.8l-1.46 1.46C4.46 15.03 4 13.57 4 12c0-4.42 3.58-8 8-8zm0 14c3.31 0 6-2.69 6-6 0-1.01-.25-1.97-.7-2.8l1.46-1.46c.78 1.23 1.24 2.69 1.24 4.26 0 4.42-3.58 8-8 8v3l-4-4 4-4v3z"})}),Sync:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"})}),Wifi:e=>{const t=e.bars??3;return i("svg",{style:k,viewBox:"0 0 24 24",children:[t>=1&&i("path",{d:"M12 18c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"}),t>=2&&i("path",{d:"M12 14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2h2c0-2.21-1.79-4-4-4z",opacity:t>=2?1:.3}),t>=3&&i("path",{d:"M12 10c-4.42 0-8 3.58-8 8h2c0-3.31 2.69-6 6-6s6 2.69 6 6h2c0-4.42-3.58-8-8-8z",opacity:t>=3?1:.3})]})},Clock:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"})}),ExternalLink:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"})}),Display:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M21 3H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h5v2h8v-2h5c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 14H3V5h18v12z"})}),Settings:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"})}),Screen:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M20 3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h3l-1 1v2h12v-2l-1-1h3c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 13H4V5h16v11z"})}),Chip:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M9 3V1H7v2H5c-1.1 0-2 .9-2 2v2h2V5h2v2h2V5h2v2h2V5h2v2h2V5c0-1.1-.9-2-2-2h-2V1h-2v2H9zM3 9h2v2H3V9zm0 4h2v2H3v-2zm18 0h2v2h-2v-2zm0-4h2v2h-2V9zM3 17v2c0 1.1.9 2 2 2h2v-2H5v-2H3zm4 4v2h2v-2H7zm4 0v2h2v-2h-2zm4 0v2h2v-2h-2zm4-4v2h-2v2h2c1.1 0 2-.9 2-2v-2h-2z"})}),Cog:()=>i("svg",{style:k,viewBox:"0 0 24 24",children:i("path",{d:"M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"})})};function Qt(){const{status:e,translations:t,language:n,setLanguage:s,setPower:o,refresh:r}=ye(),[l,d]=C(!1),[h,c]=C(!1),p=e?.winderEnabled===1;return i(I,{children:[i("header",{class:"header",children:i("div",{class:"header-content",children:[i("h1",{class:"logo",children:[i(T.Watch,{}),"Winderoo"]}),i("div",{class:"header-actions",children:[i("div",{class:"power-toggle",children:[i("span",{class:"toggle-label",children:p?t.header.on:t.header.off}),i("button",{class:`toggle ${p?"active":""}`,onClick:()=>o(!p),"aria-label":"Toggle power"})]}),i("button",{class:"btn btn-outline btn-icon",onClick:()=>c(!0),title:t.header.reset,children:i(T.Bolt,{})}),i("div",{class:"lang-menu-wrapper",children:[i("button",{class:"btn btn-outline btn-icon",onClick:()=>d(!l),children:i(T.Globe,{})}),l&&i("div",{class:"lang-menu",children:Zt.map(a=>i("button",{class:`lang-option ${n===a.code?"active":""}`,onClick:()=>{s(a.code),d(!1)},children:a.name},a.code))})]})]})]})}),h&&i("div",{class:"dialog-overlay",onClick:()=>c(!1),children:i("div",{class:"dialog",onClick:a=>a.stopPropagation(),children:[i("h2",{children:t.header.dialog.title}),i("p",{class:"text-secondary mt-2",children:t.header.dialog.subtitle}),i("ul",{class:"reset-steps",children:[i("li",{children:t.header.dialog.point1}),i("li",{children:[t.header.dialog.point2," ",i("strong",{children:"Winderoo"})]}),i("li",{children:t.header.dialog.point3}),i("li",{children:t.header.dialog.point4})]}),i("p",{class:"text-sm text-muted mt-3",children:t.header.dialog.nowAvailable}),i("code",{class:"hostname",children:"http://winderoo.local"}),i("div",{class:"dialog-actions",children:[i("button",{class:"btn btn-outline",onClick:()=>c(!1),children:t.header.dialog.cancel}),i("button",{class:"btn btn-danger",onClick:async()=>{await O.reset(),c(!1),setTimeout(r,2e4)},children:t.header.dialog.confirmReset})]})]})}),i("style",{children:`
        .header {
          background: var(--bg-secondary);
          border-bottom: 1px solid var(--border);
          padding: 1rem;
          position: sticky;
          top: 0;
          z-index: 100;
          backdrop-filter: blur(10px);
        }

        .header-content {
          max-width: 600px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .logo {
          font-size: 1.25rem;
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: linear-gradient(135deg, var(--accent), var(--accent-hover));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .power-toggle {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .toggle-label {
          font-size: 0.75rem;
          text-transform: uppercase;
          font-weight: 600;
          color: var(--text-secondary);
        }

        .lang-menu-wrapper {
          position: relative;
        }

        .lang-menu {
          position: absolute;
          top: 100%;
          right: 0;
          margin-top: 0.5rem;
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          overflow: hidden;
          min-width: 140px;
          box-shadow: var(--shadow);
        }

        .lang-option {
          width: 100%;
          padding: 0.75rem 1rem;
          text-align: left;
          transition: var(--transition);
        }

        .lang-option:hover {
          background: var(--bg-card-hover);
        }

        .lang-option.active {
          color: var(--accent);
          background: var(--accent-glow);
        }

        .dialog-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 1rem;
          z-index: 200;
          backdrop-filter: blur(4px);
        }

        .dialog {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          padding: 1.5rem;
          max-width: 400px;
          width: 100%;
        }

        .reset-steps {
          margin: 1rem 0;
          padding-left: 1.25rem;
          color: var(--text-secondary);
          font-size: 0.875rem;
        }

        .reset-steps li {
          margin-bottom: 0.5rem;
        }

        .hostname {
          display: block;
          background: var(--bg-secondary);
          padding: 0.5rem 1rem;
          border-radius: var(--radius-sm);
          font-size: 0.875rem;
          margin-top: 0.5rem;
        }

        .dialog-actions {
          display: flex;
          gap: 0.75rem;
          margin-top: 1.5rem;
          justify-content: flex-end;
        }
      `})]})}function Xt(e,t){return t===0?{label:"Off",level:"off"}:e==="Winding"?{label:"Running",level:"active"}:e==="Paused"?{label:"Paused",level:"idle"}:{label:"Stopped",level:"idle"}}function Yt(e){return e<=50?{label:"Excellent",level:"excellent"}:e<=60?{label:"Good",level:"good"}:e<=70?{label:"Fair",level:"fair"}:e<=80?{label:"Weak",level:"weak"}:{label:"No Signal",level:"none"}}function en(e){return e<=50?4:e<=60?3:e<=70?2:e<=80?1:0}function tn(){const{status:e,translations:t}=ye();if(!e)return null;const n=Yt(e.db),s=en(e.db),o=Xt(e.status,e.winderEnabled);return i(I,{children:[i("div",{class:"status-bar",children:i("div",{class:"status-bar-content",children:[i("div",{class:`status-item motor-${o.level}`,children:[i("div",{class:"status-icon",children:i(T.Cog,{})}),i("div",{class:"status-info",children:[i("span",{class:"status-label",children:t.statusBar?.motor||"Motor"}),i("span",{class:"status-value",children:o.label})]})]}),i("div",{class:`status-item ${n.level}`,children:[i("div",{class:"status-icon",children:i(nn,{bars:s})}),i("div",{class:"status-info",children:[i("span",{class:"status-label",children:t.statusBar?.wifi||"WiFi"}),i("span",{class:"status-value",children:[n.label," (-",e.db," dBm)"]})]})]}),i("div",{class:`status-item ${e.screenEquipped?"connected":"disconnected"}`,children:[i("div",{class:"status-icon",children:i(T.Screen,{})}),i("div",{class:"status-info",children:[i("span",{class:"status-label",children:t.statusBar?.screen||"Screen"}),i("span",{class:"status-value",children:e.screenEquipped?t.statusBar?.connected||"Connected":t.statusBar?.notConnected||"Not Connected"})]})]}),i("div",{class:"status-item version",children:[i("div",{class:"status-icon",children:i(T.Chip,{})}),i("div",{class:"status-info",children:[i("span",{class:"status-label",children:t.statusBar?.firmware||"Firmware"}),i("span",{class:"status-value",children:["v",e.apiVersion]})]})]})]})}),i("style",{children:`
        .status-bar {
          background: var(--bg-secondary);
          border-bottom: 1px solid var(--border);
          padding: 0.5rem 1rem;
        }

        .status-bar-content {
          max-width: 600px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 1rem;
          flex-wrap: wrap;
        }

        .status-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.25rem 0.5rem;
          border-radius: var(--radius-sm);
          background: var(--bg-card);
          border: 1px solid var(--border);
          min-width: 0;
          flex: 1;
        }

        .status-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 24px;
          height: 24px;
          flex-shrink: 0;
        }

        .status-icon svg {
          width: 18px;
          height: 18px;
        }

        .status-info {
          display: flex;
          flex-direction: column;
          min-width: 0;
        }

        .status-label {
          font-size: 0.65rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--text-muted);
          font-weight: 600;
        }

        .status-value {
          font-size: 0.75rem;
          color: var(--text-secondary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* WiFi signal levels */
        .status-item.excellent .status-icon svg {
          color: var(--success);
        }
        .status-item.excellent .status-value {
          color: var(--success);
        }

        .status-item.good .status-icon svg {
          color: var(--success);
        }
        .status-item.good .status-value {
          color: var(--success);
        }

        .status-item.fair .status-icon svg {
          color: var(--warning);
        }
        .status-item.fair .status-value {
          color: var(--warning);
        }

        .status-item.weak .status-icon svg {
          color: var(--danger);
        }
        .status-item.weak .status-value {
          color: var(--danger);
        }

        .status-item.none .status-icon svg {
          color: var(--text-muted);
        }

        /* Connection status */
        .status-item.connected .status-icon svg {
          color: var(--success);
        }
        .status-item.connected .status-value {
          color: var(--success);
        }

        .status-item.disconnected .status-icon svg {
          color: var(--text-muted);
        }
        .status-item.disconnected .status-value {
          color: var(--text-muted);
        }

        /* Version */
        .status-item.version .status-icon svg {
          color: var(--accent);
        }

        /* Motor status */
        .status-item.motor-active .status-icon svg {
          color: var(--success);
          animation: spin 2s linear infinite;
        }
        .status-item.motor-active .status-value {
          color: var(--success);
        }

        .status-item.motor-idle .status-icon svg {
          color: var(--warning);
        }
        .status-item.motor-idle .status-value {
          color: var(--warning);
        }

        .status-item.motor-off .status-icon svg {
          color: var(--text-muted);
        }
        .status-item.motor-off .status-value {
          color: var(--text-muted);
        }

        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @media (max-width: 480px) {
          .status-bar-content {
            gap: 0.5rem;
          }
          .status-item {
            padding: 0.25rem 0.375rem;
          }
          .status-label {
            font-size: 0.6rem;
          }
          .status-value {
            font-size: 0.7rem;
          }
        }
      `})]})}function nn({bars:e}){return i("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[i("path",{d:"M12 20h.01",opacity:e>=0?1:.2}),i("path",{d:"M8.5 16.429a5 5 0 0 1 7 0",opacity:e>=1?1:.2}),i("path",{d:"M5 12.859a10 10 0 0 1 14 0",opacity:e>=2?1:.2}),i("path",{d:"M1.5 9.11a15 15 0 0 1 21 0",opacity:e>=3?1:.2})]})}function rn(e){const[t,n]=C(e),s=Ct(null);return be(()=>(n(e),s.current&&clearInterval(s.current),s.current=window.setInterval(()=>{n(o=>o+1)},1e3),()=>{s.current&&clearInterval(s.current)}),[e]),t}function sn(e){return new Date(e*1e3).toLocaleTimeString("en-US",{timeZone:"UTC",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:!1})}const ce=Array.from({length:24},(e,t)=>t.toString().padStart(2,"0")),on=["00","10","20","30","40","50"],Re=Array.from({length:60},(e,t)=>t.toString().padStart(2,"0")),an=[{value:-12,label:"UTC-12:00"},{value:-11,label:"UTC-11:00"},{value:-10,label:"UTC-10:00"},{value:-9,label:"UTC-09:00"},{value:-8,label:"UTC-08:00"},{value:-7,label:"UTC-07:00"},{value:-6,label:"UTC-06:00"},{value:-5,label:"UTC-05:00"},{value:-4,label:"UTC-04:00"},{value:-3,label:"UTC-03:00"},{value:-2,label:"UTC-02:00"},{value:-1,label:"UTC-01:00"},{value:0,label:"UTC±00:00"},{value:1,label:"UTC+01:00"},{value:2,label:"UTC+02:00"},{value:3,label:"UTC+03:00"},{value:4,label:"UTC+04:00"},{value:5,label:"UTC+05:00"},{value:5.5,label:"UTC+05:30"},{value:6,label:"UTC+06:00"},{value:7,label:"UTC+07:00"},{value:8,label:"UTC+08:00"},{value:9,label:"UTC+09:00"},{value:10,label:"UTC+10:00"},{value:11,label:"UTC+11:00"},{value:12,label:"UTC+12:00"}];function ln(){const{status:e,loading:t,translations:n,refresh:s}=ye(),[o,r]=C(!1),[l,d]=C("CW"),[h,c]=C(650),[p,a]=C(!1),[m,_]=C("08"),[g,x]=C("00"),[w,v]=C(!1),[f,D]=C(!1),[z,B]=C({hour:"08",minute:"00"}),[W,L]=C({hour:"22",minute:"00"}),[U,A]=C(180),[H,E]=C(15),[P,we]=C(8),[Ce,Se]=C(0),[re,xe]=C(!1);be(()=>{if(e){if(d(e.direction),c(e.rotationsPerDay),a(e.timerEnabled===1),_(e.hour),x(e.minutes),v(e.screenSleep),D(e.screenScheduleEnabled),e.screenScheduleStartTime){const[u,$]=e.screenScheduleStartTime.split(":");B({hour:u,minute:$})}if(e.screenScheduleEndTime){const[u,$]=e.screenScheduleEndTime.split(":");L({hour:u,minute:$})}A(e.customWindDuration||180),E(e.customWindPauseDuration||15),we(e.customDurationInSecondsToCompleteOneRevolution),Se(e.gmtOffset),xe(e.dst)}},[e]);const nt=rn(e?.currentTimeEpoch||0);if(t||!e)return i("div",{class:"settings-loading",children:[i("div",{class:"spinner"}),i("p",{children:n.settings.loading})]});if(e.winderEnabled===0)return null;const it=()=>{const u=h*P,Z=u/U*H,J=u+Z,dt=Math.floor(J/3600),ut=Math.floor(J%3600/60);return{hours:dt,mins:ut}},se=(()=>{if(e.status!=="Winding")return 0;const{startTimeEpoch:u,currentTimeEpoch:$,estimatedRoutineFinishEpoch:Z}=e;if($>=Z)return 100;const J=($-u)/(Z-u);return Math.max(0,Math.min(100,J*100))})(),rt=e.db<=30?3:e.db<=60?2:1,oe=u=>({action:u,rotationDirection:l,tpd:h,hour:m,minutes:g,timerEnabled:p?1:0,screenSleep:w,screenScheduleEnabled:f,screenScheduleStartTime:`${z.hour}:${z.minute}`,screenScheduleEndTime:`${W.hour}:${W.minute}`,customWindDuration:U,customWindPauseDuration:H,customDurationInSecondsToCompleteOneRevolution:P,rtcGmtOffset:Ce,rtcDST:re}),st=async()=>{r(!0);try{const u=e.status==="Winding"?"START":"STOP";await O.updateSettings(oe(u)),await s()}finally{r(!1)}},ot=async()=>{r(!0);try{await O.updateSettings(oe("START")),await s()}finally{r(!1)}},at=async()=>{r(!0);try{await O.updateSettings(oe("STOP")),await s()}finally{r(!1)}},ke=it(),lt=e.status==="Winding"?n.settings.winding:n.settings.stopped,ct={CW:n.settings.clockwise,CCW:n.settings.counterClockwise,BOTH:n.settings.both},G=u=>({min:Math.floor(u/60),sec:u%60});return i("main",{class:"settings",children:[i("div",{class:`card status-card ${e.status.toLowerCase()}`,children:i("div",{class:"flex items-center justify-between",children:[i("div",{class:"flex items-center gap-2",children:[i("span",{class:`status-dot ${e.status.toLowerCase()}`}),i("span",{class:"font-medium",children:n.settings.status})]}),i("div",{class:"flex items-center gap-3",children:[i("span",{class:"font-semibold",children:lt}),i(T.Wifi,{bars:rt})]})]})}),i("div",{class:"card",children:i("div",{class:"control-buttons",children:[i("button",{class:"btn btn-success",onClick:ot,disabled:o,children:[i(T.Play,{})," Start"]}),i("button",{class:"btn btn-danger",onClick:at,disabled:o,children:[i(T.Stop,{})," Stop"]})]})}),e.status==="Winding"&&i("div",{class:"card",children:[i("div",{class:"flex items-center justify-between mb-2",children:[i("span",{children:se<5?n.settings.pleaseWait:n.settings.progress}),i("span",{class:"font-semibold",children:[Math.round(se),"%"]})]}),i("div",{class:"progress",children:i("div",{class:"progress-bar",style:{width:`${se}%`}})})]}),i("div",{class:"card",children:i("div",{class:"setting-row",children:[i("span",{children:n.settings.estimatedDuration}),i("span",{class:"setting-value",children:[ke.hours,"h ",ke.mins,"m"]})]})}),i("div",{class:"card",children:[i("div",{class:"setting-section",children:[i("label",{children:n.settings.direction}),i("div",{class:"setting-value mb-2",children:ct[l]}),i("div",{class:"direction-toggles",children:["CW","BOTH","CCW"].map(u=>i("button",{class:`dir-btn ${l===u?"active":""}`,onClick:()=>d(u),children:[u==="CW"&&i(T.RotateCW,{}),u==="CCW"&&i(T.RotateCCW,{}),u==="BOTH"&&i(T.Sync,{})]},u))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{children:n.settings.rotationsPerDay}),i("div",{class:"setting-value",children:h}),i("input",{type:"range",class:"slider",min:100,max:960,step:20,value:h,onInput:u=>c(Number(u.target.value))})]}),i("a",{href:"https://watch-winder.store/watch-winding-table/",target:"_blank",rel:"noopener",class:"btn btn-outline w-full mt-4",children:[i(T.ExternalLink,{}),n.settings.findWindingParameters]})]}),i("div",{class:"card",children:i("div",{class:"setting-section",children:[i("div",{class:"flex items-center justify-between",children:[i("label",{children:n.settings.cycleStart}),i("button",{class:`toggle ${p?"active":""}`,onClick:()=>a(!p)})]}),i("div",{class:"text-xs text-muted mt-1",children:p?n.settings.enabled.toUpperCase():n.settings.disabled.toUpperCase()}),p&&i("div",{class:"time-selects mt-3",children:[i("select",{class:"select",value:m,onChange:u=>_(u.target.value),children:ce.map(u=>i("option",{value:u,children:u},u))}),i("span",{class:"time-colon",children:":"}),i("select",{class:"select",value:g,onChange:u=>x(u.target.value),children:on.map(u=>i("option",{value:u,children:u},u))})]})]})}),e.screenEquipped&&i("div",{class:"card",children:[i("div",{class:"setting-section",children:[i("div",{class:"flex items-center justify-between",children:[i("label",{class:"flex items-center gap-2",children:[i(T.Display,{}),n.settings.screen]}),i("button",{class:`toggle ${w?"":"active"}`,onClick:()=>v(!w)})]}),i("div",{class:"text-xs text-muted mt-1",children:w?n.settings.disabled.toUpperCase():n.settings.enabled.toUpperCase()})]}),i("div",{class:"setting-section mt-4",children:[i("div",{class:"flex items-center justify-between",children:[i("label",{children:n.settings.screenSchedule}),i("button",{class:`toggle ${f?"active":""}`,onClick:()=>D(!f)})]}),f&&i("div",{class:"schedule-times mt-3",children:[i("div",{class:"schedule-row",children:[i("span",{class:"text-sm",children:n.settings.turnOnScreenAt}),i("div",{class:"time-selects",children:[i("select",{class:"select",value:z.hour,onChange:u=>B({...z,hour:u.target.value}),children:ce.map(u=>i("option",{value:u,children:u},u))}),i("span",{class:"time-colon",children:":"}),i("select",{class:"select",value:z.minute,onChange:u=>B({...z,minute:u.target.value}),children:Re.map(u=>i("option",{value:u,children:u},u))})]})]}),i("div",{class:"schedule-row",children:[i("span",{class:"text-sm",children:n.settings.turnOffScreenAt}),i("div",{class:"time-selects",children:[i("select",{class:"select",value:W.hour,onChange:u=>L({...W,hour:u.target.value}),children:ce.map(u=>i("option",{value:u,children:u},u))}),i("span",{class:"time-colon",children:":"}),i("select",{class:"select",value:W.minute,onChange:u=>L({...W,minute:u.target.value}),children:Re.map(u=>i("option",{value:u,children:u},u))})]})]})]})]})]}),i("div",{class:"card",children:[i("h3",{class:"flex items-center gap-2 mb-4",children:[i(T.Settings,{}),n.settings.customize]}),i("div",{class:"setting-section",children:[i("label",{children:n.settings.rotationDurationTime}),i("div",{class:"setting-value",children:[G(U).min,"m ",G(U).sec,"s"]}),i("input",{type:"range",class:"slider",min:100,max:960,step:10,value:U,onInput:u=>A(Number(u.target.value))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{children:n.settings.rotationPauseTime}),i("div",{class:"setting-value",children:[G(H).min,"m ",G(H).sec,"s"]}),i("input",{type:"range",class:"slider",min:10,max:900,step:5,value:H,onInput:u=>E(Number(u.target.value))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{children:n.settings.singleRotationTiming}),i("div",{class:"setting-value",children:[P," ",n.settings.seconds]}),i("input",{type:"range",class:"slider",min:1,max:16,step:1,value:P,onInput:u=>we(Number(u.target.value))})]}),i("div",{class:"setting-section mt-4",children:[i("label",{class:"flex items-center gap-2",children:[i(T.Clock,{}),n.settings.internalClock]}),i("div",{class:"setting-value",children:sn(nt)}),i("p",{class:"text-xs text-muted mt-2",children:n.settings.internalClockBlurb}),i("div",{class:"mt-3",children:[i("label",{class:"text-sm",children:n.settings.utcOffset}),i("select",{class:"select w-full mt-1",value:Ce,onChange:u=>Se(Number(u.target.value)),children:an.map(u=>i("option",{value:u.value,children:u.label},u.value))})]}),i("div",{class:"flex items-center justify-between mt-3",children:[i("label",{children:n.settings.dst}),i("button",{class:`toggle ${re?"active":""}`,onClick:()=>xe(!re)})]})]})]}),i("div",{class:"card",children:i("button",{class:"btn btn-primary w-full",onClick:st,disabled:o,children:o?n.settings.saveInProgress:n.settings.save})}),i("style",{children:`
        .settings {
          max-width: 600px;
          margin: 0 auto;
          padding: 1rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
          padding-bottom: 2rem;
        }

        .settings-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 60vh;
          gap: 1rem;
        }

        .spinner {
          width: 40px;
          height: 40px;
          border: 3px solid var(--border);
          border-top-color: var(--accent);
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        .status-card.winding {
          border-color: var(--success);
          box-shadow: 0 0 20px var(--success-glow);
        }

        .status-card.stopped {
          border-color: var(--danger);
        }

        .control-buttons {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .setting-section {
          padding-bottom: 1rem;
          border-bottom: 1px solid var(--border);
        }

        .setting-section:last-child {
          border-bottom: none;
          padding-bottom: 0;
        }

        .setting-section label {
          font-weight: 500;
          color: var(--text-secondary);
          font-size: 0.875rem;
        }

        .setting-value {
          font-size: 1.25rem;
          font-weight: 600;
          color: var(--text-primary);
          margin: 0.25rem 0;
        }

        .setting-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .direction-toggles {
          display: flex;
          gap: 0.5rem;
        }

        .dir-btn {
          flex: 1;
          padding: 0.75rem;
          border: 2px solid var(--border);
          border-radius: var(--radius-md);
          transition: var(--transition);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .dir-btn:hover {
          border-color: var(--accent);
          color: var(--accent);
        }

        .dir-btn.active {
          background: var(--accent);
          border-color: var(--accent);
          color: white;
        }

        .time-selects {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .time-selects .select {
          width: 80px;
        }

        .time-colon {
          font-size: 1.25rem;
          font-weight: 600;
        }

        .schedule-times {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .schedule-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        @media (max-width: 400px) {
          .control-buttons {
            grid-template-columns: 1fr;
          }

          .schedule-row {
            flex-direction: column;
            align-items: flex-start;
          }
        }
      `})]})}function cn(){return i(Kt,{children:[i(Qt,{}),i(tn,{}),i(ln,{})]})}vt(i(cn,{}),document.getElementById("app"));
